import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { join } from 'node:path'

import {
  createRendererState,
  type RendererState,
} from '/home/satont/.codex/worktrees/performance-next/chat/packages/desktop/node_modules/@gpuix/native/dist/host'
import sharp from '/home/satont/.codex/worktrees/performance-next/chat/packages/desktop/node_modules/sharp'
import { benchmarkProvenanceSchema } from '/home/satont/.codex/worktrees/performance-next/chat/packages/desktop/scripts/bench-metrics'
import {
  focusNativeQaWindow,
  getNativeQaWindowGeometry,
} from '/home/satont/.codex/worktrees/performance-next/chat/packages/desktop/scripts/qa-x11'
import { nativeWindow } from '/home/satont/.codex/worktrees/performance-next/chat/packages/desktop/src/gpuix/native-window'
import { assertGuiQaEnvironment } from '/home/satont/.codex/worktrees/performance-next/chat/packages/desktop/src/services/gui-qa'
import {
  captureGuiQaDisplay,
  decodeQaFramebuffer,
} from '/home/satont/.codex/worktrees/performance-next/chat/packages/desktop/src/services/gui-qa-screenshot'

assertGuiQaEnvironment()
assert.equal(process.env.TWIRCHAT_QA_COMPOSITOR, 'xvfb')
const provenance = benchmarkProvenanceSchema.parse(JSON.parse(process.argv[2] ?? '{}'))
const session = process.env.TWIRCHAT_QA_SESSION_DIR
assert(session, 'Private launcher session required')
await import('/home/satont/.codex/worktrees/performance-next/chat/packages/desktop/src/gpuix/native-bootstrap')
const { GpuixRenderer } =
  await import('/home/satont/.codex/worktrees/performance-next/chat/packages/desktop/node_modules/@gpuix/native')
const { startFrameLoop } =
  await import('/home/satont/.codex/worktrees/performance-next/chat/packages/desktop/node_modules/@gpuix/react')
const title = 'TwirChat cached flow QA'
const clicks: number[] = []
let pasted = ''
let host: RendererState | undefined
const renderer = new GpuixRenderer((error, event) => {
  if (error) throw error
  host?.dispatch(event)
  if (event.eventType === 'click') clicks.push(event.elementId)
  if (event.eventType === 'change' && event.elementId === 3) pasted = event.value ?? ''
})
const window = nativeWindow(renderer)
const state = createRendererState(renderer)
host = state
const binding = state.attach()
renderer.init({ title, width: 420, height: 300, focus: false })
renderer.setWindowKeyEvents(true, false, binding.windowKeyEventId)
const loop = startFrameLoop(renderer)
const hash = (bytes: Buffer | string) => createHash('sha256').update(bytes).digest('hex')
type Box = NonNullable<ReturnType<typeof window.getPaintedElementBounds>>
type Geometry = ReturnType<typeof getNativeQaWindowGeometry>
interface StageResult {
  width: number
  height: number
  visibleTextCount: number
  boundsHash: string
  glyphHash: string
  glyphColors: number
  selection: string
  clicks: number
  longWord: Box
  toolbar: { bounds: Box; clicks: number }
  longWordBounds: Array<{ id: number; bounds: Box }>
  flowBounds: Array<{ id: number; bounds: Box }>
}
const results: StageResult[] = []
function batch(operations: unknown[]) {
  renderer.applyBatch(JSON.stringify(operations))
}
async function until(check: () => boolean | Promise<boolean>, label: string) {
  const deadline = performance.now() + 8000
  while (performance.now() < deadline) {
    if (await check()) return
    await Bun.sleep(20)
  }
  throw new Error(`Timed out: ${label}`)
}
function box(id: number): Box {
  const bounds = window.getPaintedElementBounds(id)
  assert(bounds && bounds.width > 0 && bounds.height > 0, `Painted bounds ${id}`)
  return bounds
}
async function framebuffer() {
  const path = join(session, 'framebuffer', 'Xvfb_screen0')
  for (let attempt = 0; attempt < 20; attempt++) {
    const first = Buffer.from(await Bun.file(path).arrayBuffer())
    const second = Buffer.from(await Bun.file(path).arrayBuffer())
    if (first.equals(second)) return decodeQaFramebuffer(second)
  }
  throw new Error('Private framebuffer did not settle')
}
async function pixels(bounds: Box, geometry: Geometry, name?: string) {
  const frame = await framebuffer()
  const left = Math.ceil(geometry.x + bounds.x),
    top = Math.ceil(geometry.y + bounds.y)
  const width = Math.floor(geometry.x + bounds.x + bounds.width) - left
  const height = Math.floor(geometry.y + bounds.y + bounds.height) - top
  assert(
    left >= 0 &&
      top >= 0 &&
      width > 0 &&
      height > 0 &&
      left + width <= frame.width &&
      top + height <= frame.height,
  )
  const bytes = await sharp(frame.pixels, {
    raw: { width: frame.width, height: frame.height, channels: 4 },
  })
    .extract({ left, top, width, height })
    .raw()
    .toBuffer()
  if (name)
    await sharp(bytes, { raw: { width, height, channels: 4 } })
      .png()
      .toFile(join(session, `${name}.png`))
  return bytes
}
async function colored(id: number, geometry: Geometry, rgb: number[]) {
  const bounds = window.getPaintedElementBounds(id)
  if (!bounds || bounds.width <= 0 || bounds.height <= 0) return false
  const bytes = await pixels(bounds, geometry)
  let matching = 0
  for (let offset = 0; offset < bytes.length; offset += 4)
    if (rgb.every((channel, index) => Math.abs((bytes[offset + index] ?? -1000) - channel) <= 3))
      matching++
  return matching > (bytes.length / 4) * 0.7
}
function paint(index: number) {
  batch([
    [
      'setStyle',
      1,
      {
        width: '100%',
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
        backgroundColor: index % 2 ? '#171923' : '#181a24',
        color: '#edf2ff',
        fontSize: 18,
      },
    ],
  ])
}
const words = [
  'Ordinary',
  'wrapping words preserve glyphs and punctuation',
  'UnbreakableSupercalifragilisticexpialidocious0123456789',
]
const textIds: number[] = []
const assets = await Promise.all(
  [
    [235, 35, 65],
    [25, 210, 100],
    [35, 80, 240],
  ].map(async (rgb) => {
    const bytes = await sharp({
      create: {
        width: 32,
        height: 32,
        channels: 4,
        background: { r: rgb[0] ?? 0, g: rgb[1] ?? 0, b: rgb[2] ?? 0, alpha: 1 },
      },
    })
      .png()
      .toBuffer()
    const path = join(session, `static-${rgb.join('-')}.png`)
    await Bun.write(path, bytes)
    return { path, uri: `data:image/png;base64,${bytes.toString('base64')}`, rgb }
  }),
)
const red = assets[0],
  green = assets[1],
  blue = assets[2]
assert(red && green && blue)
const fixture: unknown[] = [
  ['createElement', 1, 'div'],
  ['setRoot', 1],
  ['createElement', 4, 'div'],
  ['setStyle', 4, { width: '100%', flexGrow: 1, minHeight: 0 }],
  ['appendChild', 1, 4],
  ['createElement', 2, 'virtual-list'],
  ['setStyle', 2, { width: '100%', height: '100%' }],
  ['setCustomProp', 2, 'estimatedItemHeight', 140],
  ['appendChild', 4, 2],
  ['createElement', 3, 'input'],
  ['setStyle', 3, { width: '100%', height: 28, flexShrink: 0 }],
  ['setEventListener', 3, 'change', true],
  ['appendChild', 1, 3],
]
for (let row = 0; row < 16; row++) {
  const id = 100 + row * 20
  fixture.push(
    ['createElement', id, 'div'],
    ['setStyle', id, { width: '100%' }],
    ['appendChild', 2, id],
    ['createElement', id + 1, 'div'],
    [
      'setStyle',
      id + 1,
      { display: 'flex', flexDirection: 'column', padding: 12, userSelect: 'text' },
    ],
    ['appendChild', id, id + 1],
    ['createElement', id + 2, 'div'],
    [
      'setStyle',
      id + 2,
      {
        display: 'flex',
        flexDirection: 'row',
        flexWrap: 'wrap',
        alignItems: 'center',
        ...(row % 2 === 1 ? { minWidth: 0 } : {}),
      },
    ],
    ['appendChild', id + 1, id + 2],
  )
  for (let index = 0; index < words.length; index++) {
    const textId = id + 3 + index
    textIds.push(textId, id + 10 + index)
    fixture.push(
      ['createElement', textId, 'text'],
      ['createElement', id + 10 + index, 'text'],
      ['setText', id + 10 + index, words[index]],
      ['appendChild', textId, id + 10 + index],
      ['appendChild', id + 2, textId],
    )
  }
  fixture.push(
    ['createElement', id + 6, 'div'],
    ['setCustomProp', id + 6, 'tabIndex', 0],
    ['setEventListener', id + 6, 'click', true],
    ['setStyle', id + 6, { color: '#85b7ff' }],
    ['createElement', id + 7, 'text'],
    ['createElement', id + 13, 'text'],
    ['setText', id + 13, 'Link'],
    ['appendChild', id + 7, id + 13],
    ['appendChild', id + 6, id + 7],
    ['appendChild', id + 2, id + 6],
  )
  textIds.push(id + 7, id + 13, id + 16, id + 17)
  fixture.push(
    ['createElement', id + 14, 'div'],
    [
      'setStyle',
      id + 14,
      {
        position: 'absolute',
        top: 0,
        bottom: 0,
        right: 8,
        display: 'flex',
        flexDirection: 'row',
        alignItems: 'center',
        gap: 2,
        userSelect: 'none',
      },
    ],
    ['appendChild', id + 2, id + 14],
    ['createElement', id + 15, 'div'],
    ['setStyle', id + 15, { padding: 3, cursor: 'pointer', backgroundColor: '#385477' }],
    ['setEventListener', id + 15, 'click', true],
    ['appendChild', id + 14, id + 15],
    ['createElement', id + 16, 'text'],
    ['createElement', id + 17, 'text'],
    ['setText', id + 17, 'Copy'],
    ['appendChild', id + 16, id + 17],
    ['appendChild', id + 15, id + 16],
  )
  for (const [offset, source] of [
    [8, red.path],
    [9, green.uri],
  ] satisfies Array<[number, string]>)
    fixture.push(
      ['createElement', id + offset, 'img'],
      ['setCustomProp', id + offset, 'src', source],
      ['setStyle', id + offset, { width: 32, height: 32 }],
      ['appendChild', id + 2, id + offset],
    )
}
async function warm(geometry: Geometry) {
  const started = performance.now()
  for (let index = 0; index < 240; index++) {
    if (index % 8 === 0) paint(index / 8)
    renderer.simulateMouseMove(
      geometry.width - 20,
      15 + ((index % 24) / 24) * (geometry.height - 70),
    )
    await Bun.sleep(Math.max(0, started + ((index + 1) * 1000) / 120 - performance.now()))
  }
  paint(0)
  renderer.simulateMouseMove(0, 0)
  await Bun.sleep(100)
}
async function select(bounds: Box) {
  const x = bounds.x + 0.1,
    y = bounds.y + bounds.height / 2
  renderer.simulateMouseDown(x, y, 0)
  for (let index = 1; index <= 12; index++) {
    renderer.simulateMouseMove(x + ((bounds.width + 1) * index) / 12, y, 0)
    await Bun.sleep(12)
  }
  renderer.simulateMouseUp(x + bounds.width + 1, y, 0)
  await Bun.sleep(80)
  const selected = renderer.getSelectedText()
  assert.equal(selected?.trim(), 'Ordinary')
  renderer.simulateKeystrokes('ctrl-c')
  await Bun.sleep(80)
  pasted = ''
  renderer.focusElement(3)
  renderer.simulateKeystrokes('ctrl-a backspace ctrl-v')
  await until(() => pasted.trim() === 'Ordinary', 'native copy/paste round trip')
  renderer.clearSelection()
  return selected?.trim() ?? ''
}
try {
  batch(fixture)
  paint(0)
  // No decode wait before these first paint-only invalidations.
  for (let index = 0; index < 16; index++) {
    paint(index)
    await Bun.sleep(8)
  }
  paint(0)
  await focusNativeQaWindow(title)
  let previousLongWord: Box | undefined
  for (const size of [
    { width: 420, height: 300 },
    { width: 770, height: 900 },
  ]) {
    await window.setWindowBounds(size)
    await until(
      () =>
        window.getWindowBounds()?.width === size.width &&
        window.getWindowBounds()?.height === size.height,
      'actual client resize',
    )
    const geometry = getNativeQaWindowGeometry(title)
    assert.equal(geometry.width, size.width)
    assert.equal(geometry.height, size.height)
    await until(
      () =>
        renderer.getPaintedText().includes('Ordinary') &&
        (window.getPaintedElementBounds(102)?.width ?? 0) > size.width - 50,
      'painted flow after actual resize',
    )
    await until(
      async () =>
        (await colored(108, geometry, red.rgb)) && (await colored(109, geometry, green.rgb)),
      'file/data PNG pixels after immediate paint-only batches',
    )
    const viewport = box(4)
    const visible = textIds.flatMap((id) => {
      const bounds = window.getPaintedElementBounds(id)
      return bounds &&
        bounds.x >= viewport.x &&
        bounds.y >= viewport.y &&
        bounds.x + bounds.width <= viewport.x + viewport.width &&
        bounds.y + bounds.height <= viewport.y + viewport.height
        ? [{ id, bounds }]
        : []
    })
    assert(visible.length >= 4)
    const flowBounds = [102, 122].map((id) => ({ id, bounds: box(id) }))
    const toolbar = box(114)
    const toolbarFlow = box(102)
    const close = (actual: number, expected: number, label: string) =>
      assert(Math.abs(actual - expected) <= 0.01, `${label}: ${actual} vs ${expected}`)
    close(toolbar.y, toolbarFlow.y, 'Toolbar y matches original body')
    close(toolbar.height, toolbarFlow.height, 'Toolbar stretches to original body height')
    close(
      toolbar.x,
      toolbarFlow.x + toolbarFlow.width - 8 - toolbar.width,
      'Toolbar right inset stays eight pixels',
    )
    const word = box(103),
      longWord = box(105),
      flow = box(102)
    // Include overflowing host/raw words explicitly, independent of the fully visible set.
    const longWordBounds = [105, 112, 125, 132].map((id) => ({ id, bounds: box(id) }))
    assert(longWord.height > 0 && flow.height >= word.height)
    if (previousLongWord)
      assert(flow.height < previousLongWord.height, 'wider window rewraps immediately')
    previousLongWord = flow
    const selection = await select(word)
    renderer.blur()
    renderer.clearSelection()
    renderer.simulateMouseMove(0, 0)
    paint(0)
    await Bun.sleep(100)
    const textBefore = renderer.getPaintedText()
    const before = await pixels(word, geometry, `glyph-${size.width}-before`)
    const colors = new Set<number>()
    for (let index = 0; index < before.length; index += 4) colors.add(before.readUIntBE(index, 3))
    assert(colors.size > 2, 'Baseline crop contains actual glyphs')
    await warm(geometry)
    assert.deepEqual(renderer.getPaintedText(), textBefore)
    assert.deepEqual(
      flowBounds.map(({ id }) => ({ id, bounds: box(id) })),
      flowBounds,
      'Flow roots retain exact Direct width and geometry, including overflowing content',
    )
    assert.deepEqual(
      visible.map(({ id }) => ({ id, bounds: box(id) })),
      visible,
    )
    assert.deepEqual(
      longWordBounds.map(({ id }) => ({ id, bounds: box(id) })),
      longWordBounds,
      'Overflowing host/raw words preserve Direct geometry with minWidth absent and zero',
    )
    const after = await pixels(word, geometry, `glyph-${size.width}-after`)
    assert.deepEqual(after, before, 'Actual cached glyph RGBA identical')
    assert.equal(await select(box(103)), selection)
    renderer.blur()
    renderer.clearSelection()
    const toolbarButton = box(115)
    const tx = toolbarButton.x + toolbarButton.width / 2
    const ty = toolbarButton.y + toolbarButton.height / 2
    const toolbarClicksBefore = clicks.length
    renderer.simulateMouseDown(tx, ty, 0)
    for (let index = 0; index < 8; index++) {
      paint(index)
      batch([
        [
          'setStyle',
          115,
          { padding: 3, cursor: 'pointer', backgroundColor: index % 2 ? '#486887' : '#385477' },
        ],
      ])
      await Bun.sleep(25)
    }
    renderer.simulateMouseUp(tx, ty, 0)
    await until(
      () => clicks.length === toolbarClicksBefore + 1,
      'Overlay held press delivers exactly one Copy click',
    )
    await Bun.sleep(80)
    assert.equal(clicks.length, toolbarClicksBefore + 1)
    assert.equal(clicks.at(-1), 115)
    renderer.simulateMouseDown(tx, ty, 0)
    renderer.simulateMouseMove(size.width - 2, size.height - 2, 0)
    renderer.simulateMouseUp(size.width - 2, size.height - 2, 0)
    await Bun.sleep(80)
    assert.equal(clicks.length, toolbarClicksBefore + 1, 'Overlay release outside cancels')
    renderer.simulateMouseDown(tx, ty, 0)
    renderer.simulateMouseUp(tx, ty, 0)
    await until(() => clicks.length === toolbarClicksBefore + 2, 'Overlay retry after cancellation')
    assert.deepEqual(box(114), toolbar, 'Overlay paint-only changes preserve toolbar geometry')
    const toolbarClickCount = clicks.length - toolbarClicksBefore
    const link = box(106),
      x = link.x + link.width / 2,
      y = link.y + link.height / 2
    const beforeClicks = clicks.length
    // Force Direct layout, then activate the cache while this native press remains held.
    batch([['setText', 113, 'Link held']])
    await until(() => renderer.getPaintedText().includes('Link held'), 'Direct link mount')
    const held = box(106),
      hx = held.x + held.width / 2,
      hy = held.y + held.height / 2
    renderer.simulateMouseDown(hx, hy, 0)
    for (let index = 0; index < 8; index++) {
      paint(index)
      await Bun.sleep(25)
    }
    renderer.simulateMouseUp(hx, hy, 0)
    await until(
      () => clicks.length === beforeClicks + 1,
      'held Direct-to-cached press delivers exactly one click',
    )
    await Bun.sleep(80)
    assert.equal(clicks.length, beforeClicks + 1)
    assert.equal(clicks.at(-1), 106)
    renderer.simulateMouseDown(x, y, 0)
    renderer.simulateMouseMove(size.width - 2, size.height - 2, 0)
    renderer.simulateMouseUp(size.width - 2, size.height - 2, 0)
    await Bun.sleep(80)
    assert.equal(clicks.length, beforeClicks + 1, 'release outside cancels')
    renderer.simulateMouseDown(hx, hy, 0)
    renderer.simulateMouseUp(hx, hy, 0)
    await until(() => clicks.length === beforeClicks + 2, 'retry after cancellation')
    batch([
      ['setCustomProp', 108, 'src', blue.uri],
      ['setStyle', 108, { width: 48, height: 40 }],
      ['setText', 111, 'Replacement wraps into a different measured row layout immediately'],
    ])
    for (let index = 0; index < 8; index++) {
      paint(index)
      await Bun.sleep(8)
    }
    await until(
      async () => await colored(108, geometry, blue.rgb),
      'changed URI decoded actual blue pixels',
    )
    assert.equal(box(108).width, 48)
    assert.equal(box(108).height, 40)
    assert(
      renderer
        .getPaintedText()
        .includes('Replacement wraps into a different measured row layout immediately'),
    )
    await captureGuiQaDisplay(`cached-flow-${size.width}`)
    results.push({
      ...size,
      visibleTextCount: visible.length,
      boundsHash: hash(JSON.stringify(visible)),
      glyphHash: hash(before),
      glyphColors: colors.size,
      selection,
      clicks: clicks.length - beforeClicks,
      longWord,
      toolbar: {
        bounds: toolbar,
        clicks: toolbarClickCount,
      },
      longWordBounds,
      flowBounds,
    })
    batch([
      ['setCustomProp', 108, 'src', red.path],
      ['setStyle', 108, { width: 32, height: 32 }],
      ['setText', 111, words[1]],
      ['setText', 113, 'Link'],
    ])
  }
  const result = {
    ok: true,
    provenance,
    probeSha256: hash(Buffer.from(await Bun.file(import.meta.path).arrayBuffer())),
    stages: results,
    imageReadiness: 'file+data PNG actual pixels',
    overlayHeldPress:
      'Absolute Copy toolbar held through body revision/color changes; exactly one click plus cancel/retry',
    heldPress: 'Direct to paint-only cache, exactly one click, cancel/retry',
    softwareXvfb: true,
  }
  await Bun.write(join(session, 'cached-flow-result.json'), `${JSON.stringify(result, null, 2)}\n`)
  console.log(JSON.stringify(result))
} catch (error) {
  await captureGuiQaDisplay('cached-flow-failure')
  console.error(
    JSON.stringify({
      paintedText: renderer.getPaintedText(),
      focused: renderer.getFocusedElementId(),
      clicks,
      stages: results,
    }),
  )
  throw error
} finally {
  renderer.setWindowKeyEvents(false, false, binding.windowKeyEventId)
  binding.detach()
  window.closeWindow()
  loop.stop()
}
