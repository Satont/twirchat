import assert from 'node:assert/strict'
import { join } from 'node:path'

import { z } from '/home/satont/.codex/worktrees/performance-next/chat/packages/desktop/node_modules/zod'

import { caseName, metrics, readDataset, verifyDataset } from './load-data'

const baselineRoot = '/home/satont/.cache/twirchat/row-qa/baseline-load'
const args = z
  .tuple([z.string(), z.string(), z.string(), z.string()])
  .parse(process.argv.slice(2, 6))
const [matrixPath, ...targetPaths] = args
const baselineMatrix = await readDataset(join(baselineRoot, 'raw-final-matrix.json'))
const baselineTargets = await Promise.all(
  [1, 2, 3].map((rep) => readDataset(join(baselineRoot, `raw-final-target-${rep}.json`))),
)
const finalMatrix = await readDataset(matrixPath)
const finalTargets = await Promise.all(targetPaths.map(readDataset))
verifyDataset(
  baselineMatrix,
  false,
  '7726a43b8af0351d1025e8b283f923a3250731e90ee8b8ae0e86f5c4c5fab7f5',
)
verifyDataset(finalMatrix, false)
for (const target of baselineTargets)
  verifyDataset(target, true, baselineMatrix.provenance.sourceHash)
for (const target of finalTargets) verifyDataset(target, true, finalMatrix.provenance.sourceHash)
for (const final of [finalMatrix, ...finalTargets]) {
  assert.equal(final.environment.cpu, baselineMatrix.environment.cpu)
  assert.equal(final.environment.logicalCpus, baselineMatrix.environment.logicalCpus)
}
const flaggedMetrics = new Set(['cpuPercent', 'rssMedianMiB', 'rssPeakMiB'])
function pair(baseline: number, final: number) {
  return {
    baseline,
    final,
    delta: final - baseline,
    deltaPercent: baseline === 0 ? null : (final / baseline - 1) * 100,
  }
}
const matrix = baselineMatrix.results.map((baseline) => {
  const final = finalMatrix.results.find((result) => caseName(result) === caseName(baseline))
  assert(final)
  assert.deepEqual(final.config, baseline.config)
  const b = metrics(baseline),
    f = metrics(final)
  const comparisons = Object.fromEntries(
    Object.entries(b).map(([key, value]) => {
      const finalValue = Reflect.get(f, key)
      assert(finalValue === null || typeof finalValue === 'number')
      return [
        key,
        value === null || finalValue === null
          ? { baseline: value, final: finalValue, delta: null, deltaPercent: null }
          : pair(value, finalValue),
      ]
    }),
  )
  const flags = Object.entries(comparisons)
    .filter(
      ([key, value]) =>
        flaggedMetrics.has(key) && value.deltaPercent !== null && value.deltaPercent > 5,
    )
    .map(([metric]) => metric)
  return {
    case: caseName(baseline),
    config: baseline.config,
    comparisons,
    flags,
    note: flags.length
      ? 'Single matrix flag; investigate/repeat before interpreting as a confirmed regression.'
      : null,
  }
})
function distribution(values: number[]) {
  const sorted = [...values].sort((a, b) => a - b)
  const median = sorted[Math.floor(sorted.length / 2)]
  assert(median !== undefined)
  return { median, min: Math.min(...values), max: Math.max(...values), values }
}
const baseTargetMetrics = baselineTargets.flatMap((data) => data.results.map(metrics))
const finalTargetMetrics = finalTargets.flatMap((data) => data.results.map(metrics))
const first = baseTargetMetrics[0]
assert(first)
const production = Object.fromEntries(
  Object.keys(first).map((key) => {
    const values = (collection: typeof baseTargetMetrics) =>
      collection.map((metric) => {
        const value: unknown = Reflect.get(metric, key)
        assert(typeof value === 'number', `Target ${key} numeric metric`)
        return value
      })
    const baseline = distribution(values(baseTargetMetrics)),
      final = distribution(values(finalTargetMetrics))
    return [
      key,
      { baseline, final, medianDeltaPercent: pair(baseline.median, final.median).deltaPercent },
    ]
  }),
)
const productionFlags = Object.entries(production)
  .filter(
    ([key, value]) =>
      flaggedMetrics.has(key) && value.medianDeltaPercent !== null && value.medianDeltaPercent > 5,
  )
  .map(([metric]) => metric)
const rateFlags = finalTargetMetrics.flatMap((metric, index) =>
  metric.offeredRateFraction !== null && metric.offeredRateFraction < 0.99
    ? [{ run: index + 1, offeredRateFraction: metric.offeredRateFraction }]
    : [],
)
const baselineIndex = z.unknown().parse(await Bun.file(join(baselineRoot, 'index.json')).json())
const finalManifest = process.argv[7]
  ? z
      .object({ version: z.string(), sha256: z.string(), patchDigest: z.string() })
      .parse(await Bun.file(process.argv[7]).json())
  : null
const report = {
  units:
    'CPU percent of one core, memory MiB, lag ms, rate msg/s; production median/min/max/individual values',
  baselineIdentity: baselineIndex,
  finalProvenance: finalMatrix.provenance,
  finalNativeManifest: finalManifest,
  paths: { matrix: matrixPath, targets: targetPaths },
  environment: { baseline: baselineMatrix.environment, final: finalMatrix.environment },
  matrix,
  production,
  flags: {
    matrix: matrix
      .filter((row) => row.flags.length)
      .map(({ case: name, flags }) => ({ case: name, metrics: flags })),
    production: productionFlags,
    targetBelow99Percent: rateFlags,
  },
  interpretation:
    'Analysis only. Matrix singles are not repeat proof. Flags and ranges require review; this helper does not declare acceptance or maximum sustainable external throughput.',
}
if (process.argv[6]) await Bun.write(process.argv[6], `${JSON.stringify(report, null, 2)}\n`)
console.log(JSON.stringify(report, null, 2))
