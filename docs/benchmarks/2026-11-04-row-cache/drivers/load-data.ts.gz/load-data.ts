import assert from 'node:assert/strict'

import { z } from '/home/satont/.codex/worktrees/performance-next/chat/packages/desktop/node_modules/zod'
import {
  benchmarkProvenanceSchema,
  benchmarkResultSchema,
  type BenchmarkResult,
} from '/home/satont/.codex/worktrees/performance-next/chat/packages/desktop/scripts/bench-metrics'

export const datasetSchema = z.object({
  environment: z.object({
    bun: z.string(),
    reactMode: z.enum(['production', 'development']),
    cpu: z.string(),
    kernel: z.string(),
    logicalCpus: z.number(),
  }),
  provenance: benchmarkProvenanceSchema,
  results: z.array(benchmarkResultSchema),
})
export async function readDataset(path: string) {
  return datasetSchema.parse(await Bun.file(path).json())
}
export function caseName(result: BenchmarkResult) {
  return `c${result.config.channels}-r${result.config.rate}-p${result.config.panes}`
}
export function verifyDataset(
  data: z.infer<typeof datasetSchema>,
  production: boolean,
  expectedSource?: string,
) {
  assert.equal(data.environment.bun, '1.4.4')
  assert.equal(data.environment.reactMode, production ? 'production' : 'development')
  if (expectedSource) assert.equal(data.provenance.sourceHash, expectedSource)
  assert.equal(data.results.length, production ? 1 : 15)
  for (const result of data.results) {
    assert.deepEqual(result.provenance, data.provenance)
    assert.equal(result.bunVersion, '1.4.4')
    assert.equal(result.reactMode, production ? 'production' : 'development')
    assert.equal(result.config.warmupSeconds, 3)
    assert.equal(result.config.durationSeconds, production ? 30 : 12)
    assert.deepEqual(result.nativeWindow, { width: 1200, height: 800 })
    assert.equal(result.retainedMessages, result.config.channels * 200)
    assert.equal(result.termination, 'completed')
    assert.equal(result.compositor, 'weston')
    if (production) assert.equal(caseName(result), 'c50-r5000-p4')
  }
  if (!production) {
    const expected = [1, 10, 50]
      .flatMap((channels) => [0, 100, 1000, 5000].map((rate) => `c${channels}-r${rate}-p1`))
      .concat(['c50-r1000-p4', 'c50-r5000-p4', 'c100-r5000-p4'])
    assert.deepEqual(data.results.map(caseName), expected)
  }
}
export function metrics(result: BenchmarkResult) {
  return {
    cpuPercent: result.cpuPercent,
    rssMedianMiB: result.rssMedianBytes / 1048576,
    rssPeakMiB: result.rssPeakBytes / 1048576,
    jsHeapPeakMiB: result.heapPeakBytes / 1048576,
    lagP95Ms: result.eventLoopLagP95Ms,
    lagMaxMs: result.eventLoopLagMaxMs,
    achievedRate: result.achievedRate,
    offeredRateFraction: result.config.rate === 0 ? null : result.achievedRate / result.config.rate,
    processedMessages: result.processedMessages,
    processedAfterDrain: result.processedAfterDrain,
    timingEntries: result.userTimingMeasureCount ?? null,
  }
}
