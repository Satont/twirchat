import { dlopen, FFIType, ptr } from 'bun:ffi'
import { readFileSync, readdirSync } from 'node:fs'
/** @jsxImportSource /home/satont/.codex/worktrees/performance-next/chat/packages/desktop/node_modules/@gpuix/react */
if (process.env.TWIRCHAT_GUI_QA !== '1') throw new Error('Use the isolated qa:gui launcher.')
const { assertGuiQaEnvironment } =
  await import('/home/satont/.codex/worktrees/performance-next/chat/packages/desktop/src/services/gui-qa')
assertGuiQaEnvironment()

import assert from 'node:assert/strict'
import { join } from 'node:path'

import type { NativeRenderer } from '/home/satont/.codex/worktrees/performance-next/chat/packages/desktop/node_modules/@gpuix/react'
import { z } from '/home/satont/.codex/worktrees/performance-next/chat/packages/desktop/node_modules/zod'
import {
  benchmarkCaseSchema,
  benchmarkProvenanceSchema,
  benchmarkResultSchema,
  benchmarkReactModeSchema,
  gpuMeasurements,
  percentile,
  readDrmSnapshot,
  verifyBenchmarkReactMode,
  type ResourceSample,
} from '/home/satont/.codex/worktrees/performance-next/chat/packages/desktop/scripts/bench-metrics'
import type {
  NormalizedChatMessage,
  WatchedChannel,
  WatchedChannelsLayout,
} from '/home/satont/.codex/worktrees/performance-next/chat/packages/shared/types'

const React =
  await import('/home/satont/.codex/worktrees/performance-next/chat/packages/desktop/node_modules/react')
const { useGpuixRequired } =
  await import('/home/satont/.codex/worktrees/performance-next/chat/packages/desktop/node_modules/@gpuix/react')
const { getDesktopBackend } =
  await import('/home/satont/.codex/worktrees/performance-next/chat/packages/desktop/src/gpuix/backend/server')
const { DesktopWindowManager } =
  await import('/home/satont/.codex/worktrees/performance-next/chat/packages/desktop/src/gpuix/window-manager')
const { nativeWindow } =
  await import('/home/satont/.codex/worktrees/performance-next/chat/packages/desktop/src/gpuix/native-window')
const { ChatView } =
  await import('/home/satont/.codex/worktrees/performance-next/chat/packages/desktop/src/gpuix/components/ChatView')
const app =
  await import('/home/satont/.codex/worktrees/performance-next/chat/packages/desktop/src/gpuix/state/app')
const { layoutStore } =
  await import('/home/satont/.codex/worktrees/performance-next/chat/packages/desktop/src/gpuix/state/layout')
const { emotePreferencesStore } =
  await import('/home/satont/.codex/worktrees/performance-next/chat/packages/desktop/src/gpuix/state/emote-preferences')
const { DEFAULT_SETTINGS } =
  await import('/home/satont/.codex/worktrees/performance-next/chat/packages/shared/types')
const { captureGuiQaDisplay } =
  await import('/home/satont/.codex/worktrees/performance-next/chat/packages/desktop/src/services/gui-qa-screenshot')
const configuration: unknown = JSON.parse(process.argv[2] ?? '{}')
const config = benchmarkCaseSchema.parse(configuration)
const provenance = benchmarkProvenanceSchema.parse(JSON.parse(process.argv[3] ?? '{}'))
const reactMode = verifyBenchmarkReactMode({
  requested: benchmarkReactModeSchema.parse(process.argv[4] ?? 'development'),
  nodeEnv: process.env.NODE_ENV,
  hasCaptureOwnerStack: typeof React.captureOwnerStack === 'function',
  loadedModules: Object.keys(require.cache),
})
const directory = process.env.TWIRCHAT_QA_SESSION_DIR
assert.ok(directory)

interface ThreadSample {
  comm: string
  userTicks: number
  systemTicks: number
  rawStat: string
}
function threads(): Record<string, ThreadSample> {
  const result: Record<string, ThreadSample> = {}
  for (const tid of readdirSync('/proc/self/task')) {
    try {
      const rawStat = readFileSync(`/proc/self/task/${tid}/stat`, 'utf8')
      const end = rawStat.lastIndexOf(')')
      const values = rawStat
        .slice(end + 2)
        .trim()
        .split(/\s+/u)
      const userTicks = Number(values[11]),
        systemTicks = Number(values[12])
      assert(Number.isFinite(userTicks) && Number.isFinite(systemTicks))
      result[tid] = {
        comm: rawStat.slice(rawStat.indexOf('(') + 1, end),
        userTicks,
        systemTicks,
        rawStat,
      }
    } catch (error) {
      if (!(error instanceof Error && 'code' in error && error.code === 'ENOENT')) throw error
    }
  }
  return result
}
// Default process-wide timer. Keep this DLL loaded until process exit.
delete process.env.CPUPROFILE_FREQUENCY
delete process.env.CPUPROFILE_PER_THREAD_TIMERS
const profiler = dlopen('/usr/lib/libprofiler.so', {
  ProfilerStart: { args: [FFIType.ptr], returns: FFIType.i32 },
  ProfilerStop: { args: [], returns: FFIType.void },
})
const profilePath = join(directory, 'production-target.gperf')
const profileFilename = Buffer.from(`${profilePath}\0`)
let profileActive = false
let threadsBefore: Record<string, ThreadSample> = {}
let profileStarted = 0
let profileSaved = false
let threadsAfter: Record<string, ThreadSample> = {}
let elapsedMs = 0
const clockTicks = z.coerce.number().positive().parse(process.argv[5])
async function stopProfile() {
  if (profileSaved || profileStarted === 0) return
  if (profileActive) {
    profiler.symbols.ProfilerStop()
    profileActive = false
    threadsAfter = threads()
    elapsedMs = performance.now() - profileStarted
  }
  profileSaved = true
  const deltas = Object.entries(threadsAfter)
    .map(([tid, sample]) => {
      const initial = threadsBefore[tid]
      const ticks = initial
        ? sample.userTicks + sample.systemTicks - initial.userTicks - initial.systemTicks
        : null
      return {
        tid,
        comm: sample.comm,
        ticks,
        cpuPercent: ticks === null ? null : (ticks / clockTicks / (elapsedMs / 1000)) * 100,
        newThread: !initial,
      }
    })
    .sort((a, b) => (b.ticks ?? -1) - (a.ticks ?? -1))
  const header = Buffer.from(await Bun.file(profilePath).arrayBuffer())
  assert(header.length >= 40)
  const headerSlots = Array.from({ length: 5 }, (_, index) =>
    Number(header.readBigUInt64LE(index * 8)),
  )
  assert.equal(headerSlots[0], 0)
  assert.equal(headerSlots[1], 3)
  const periodMicroseconds = headerSlots[3]
  assert(periodMicroseconds && periodMicroseconds > 0)
  await Bun.write(
    join(directory, 'thread-cpu.json'),
    JSON.stringify(
      {
        diagnosticOnly: true,
        acceptanceComparable: false,
        note: 'Profiler and procfs sampler perturb execution; per-thread deltas include ProfilerStart/Stop and procfs overhead. New/exited threads have incomplete coverage; sampled call attribution can be timer-thread biased.',
        timer: 'default process-wide ITIMER_PROF; per-thread timer env removed',
        clockTicks,
        elapsedMs,
        profilePath,
        headerSlots,
        actualFrequencyHz: 1000000 / periodMicroseconds,
        before: threadsBefore,
        after: threadsAfter,
        exitedThreads: Object.keys(threadsBefore).filter((tid) => !threadsAfter[tid]),
        deltas,
      },
      null,
      2,
    ),
  )
}

const backend = getDesktopBackend()
const channels: WatchedChannel[] = Array.from({ length: config.channels }, (_, index) => ({
  id: `bench-${index}`,
  platform: 'kick',
  channelSlug: `bench-${index}`,
  displayName: `Benchmark ${index + 1}`,
  createdAt: 0,
}))
const visibleChannels = channels.slice(0, config.panes)
const layout: WatchedChannelsLayout = {
  version: 2,
  root: {
    type: 'split',
    id: 'benchmark-root',
    direction: 'horizontal',
    flex: 100,
    children: visibleChannels.map((channel) => ({
      type: 'panel',
      id: channel.id,
      flex: 100 / visibleChannels.length,
      content: { type: 'watched', channelId: channel.id },
    })),
  },
}
app.settingsStore.set({ ...DEFAULT_SETTINGS, showAvatars: false, chatTheme: 'compact' })
app.accountsStore.set([])
app.watchedChannelsStore.set(channels)
app.watchedStatusesStore.set(
  new Map(
    channels.map((channel) => [
      channel.id,
      { platform: 'kick', status: 'connected', mode: 'anonymous' },
    ]),
  ),
)
layoutStore.set(new Map([['benchmark', { layout, isLoading: false, error: null }]]))
emotePreferencesStore.update({
  value: {
    ...emotePreferencesStore.get().value,
    badges: false,
    paints: false,
    personal: false,
    enabled: { twitch: false, seventv: false, bttv: false, ffz: false },
  },
})
const stopMessages = app.wireBackendToStores(backend)
let renderer: NativeRenderer | undefined
function paintedText(current: NativeRenderer): string[] {
  const read: unknown = Reflect.get(current, 'getPaintedText')
  if (typeof read !== 'function') throw new Error('Native painted-text diagnostics unavailable.')
  return z.array(z.string()).parse(Reflect.apply(read, current, []))
}
function Content() {
  const current = useGpuixRequired()
  React.useEffect(() => {
    renderer = current
  }, [current])
  return React.createElement(
    'div',
    {
      style: {
        display: 'flex',
        flexDirection: 'row',
        width: '100%',
        height: '100%',
        backgroundColor: '#16161c',
      },
    },
    ...visibleChannels.map((channel) =>
      React.createElement(
        'div',
        {
          key: channel.id,
          style: { display: 'flex', flexDirection: 'column', flex: 1, minWidth: 0, height: '100%' },
        },
        React.createElement(ChatView, {
          paneId: `benchmark:${channel.id}`,
          layoutTabId: 'benchmark',
          layoutPanelId: channel.id,
          watchedChannel: channel,
        }),
      ),
    ),
  )
}
const manager = new DesktopWindowManager(
  backend,
  () => React.createElement(Content),
  () => {},
)
let sequence = 0
const phrases = [
  'Привет! Как проходит стрим?',
  'Nice play, that was a close one!',
  'Обсуждаем интерфейс и новые функции чата.',
  'A longer chat message with several words, punctuation, numbers 12345 and a question?',
  'Короткое сообщение.',
  'Thanks for the stream, see you next time.',
]
function inject(): void {
  const channel = channels[sequence % channels.length]
  assert.ok(channel)
  const id = sequence++
  const message: NormalizedChatMessage = {
    id: `bench-message-${id}`,
    platform: 'kick',
    channelId: channel.channelSlug,
    type: 'message',
    timestamp: new Date(),
    text: `${phrases[id % phrases.length] ?? ''} ${id % 997}`,
    author: {
      id: `viewer-${id % 256}`,
      username: `viewer${id % 256}`,
      displayName: `Viewer${id % 256}`,
      color: ['#c084fc', '#38bdf8', '#4ade80', '#fb923c'][id % 4],
      badges: [],
    },
    emotes: [],
  }
  backend.events.emit('watched_channel_message', { channelId: channel.id, message })
}
function processed(): number {
  return channels.reduce(
    (total, channel) => total + (app.chatActivityStore.get().get(channel.id)?.total ?? 0),
    0,
  )
}
async function until(check: () => boolean, label: string): Promise<void> {
  const deadline = performance.now() + 8000
  while (performance.now() < deadline) {
    if (check()) return
    await Bun.sleep(20)
  }
  throw new Error(`Timed out: ${label}`)
}
function generator(rate: number): { stop(): void; generated(): number } {
  let generated = 0
  let fraction = 0
  let previous = performance.now()
  const timer = setInterval(() => {
    const now = performance.now()
    fraction += ((now - previous) * rate) / 1000
    previous = now
    const count = Math.min(250, Math.floor(fraction))
    fraction -= Math.floor(fraction)
    for (let index = 0; index < count; index++) inject()
    generated += count
  }, 20)
  return { stop: () => clearInterval(timer), generated: () => generated }
}
try {
  await manager.start()
  await until(() => renderer !== undefined, 'native benchmark window')
  assert.ok(renderer)
  await nativeWindow(renderer).setWindowBounds({ width: 1200, height: 800 })
  assert.equal(
    await backend.api.getAccounts().then((accounts) => accounts.length),
    0,
    'Benchmark must not read real credentials.',
  )
  for (let index = 0; index < config.channels * 200; index++) inject()
  await until(
    () =>
      channels.every((channel) => app.watchedMessagesStore.get().get(channel.id)?.length === 200),
    'all channel buffers filled',
  )
  await until(
    () => renderer !== undefined && paintedText(renderer).some((text) => text.includes('Viewer')),
    'real native message text painted',
  )
  const warmup = generator(config.rate)
  await Bun.sleep(config.warmupSeconds * 1000)
  warmup.stop()
  await Bun.sleep(100)
  if (process.env.TWIRCHAT_QA_COMPOSITOR === 'xvfb') await captureGuiQaDisplay('benchmark-before')
  const initialProcessed = processed()
  const baselineMemory = process.memoryUsage()
  const initialGpu = readDrmSnapshot()
  let lastGpu = initialGpu
  const samples: ResourceSample[] = []
  const lags: number[] = []
  threadsBefore = threads()
  profileStarted = performance.now()
  assert.equal(profiler.symbols.ProfilerStart(ptr(profileFilename)), 1, 'Profiler starts once')
  profileActive = true
  const cpuStart = process.cpuUsage()
  const start = performance.now()
  const ending = Promise.withResolvers<'completed' | 'rss-limit'>()
  const deadline = setTimeout(() => ending.resolve('completed'), config.durationSeconds * 1000)
  let expected = start + 50
  const lagTimer = setInterval(() => {
    const now = performance.now()
    lags.push(Math.max(0, now - expected))
    expected = now + 50
  }, 50)
  const sample = () => {
    const memory = process.memoryUsage()
    const next = readDrmSnapshot()
    samples.push({
      elapsedMs: performance.now() - start,
      rssBytes: memory.rss,
      heapBytes: memory.heapUsed,
      processed: processed() - initialProcessed,
      gpu: gpuMeasurements(lastGpu, next),
    })
    lastGpu = next
    if (memory.rss > 2 * 1024 ** 3) ending.resolve('rss-limit')
  }
  const sampleTimer = setInterval(sample, 250)
  const load = generator(config.rate)
  const termination = await ending.promise
  load.stop()
  clearTimeout(deadline)
  clearInterval(lagTimer)
  clearInterval(sampleTimer)
  const wallMs = performance.now() - start
  const cpu = process.cpuUsage(cpuStart)
  profiler.symbols.ProfilerStop()
  profileActive = false
  threadsAfter = threads()
  elapsedMs = performance.now() - profileStarted
  const count = processed() - initialProcessed
  sample()
  const endGpu = readDrmSnapshot()
  const userTimingMeasureCount = performance.getEntriesByType('measure').length
  await stopProfile()
  await Bun.sleep(2000)
  const bounds = nativeWindow(renderer).getWindowBounds()
  assert.ok(bounds)
  assert.equal(bounds.width, 1200)
  assert.equal(bounds.height, 800)
  const requestedMessages = Math.floor((config.rate * wallMs) / 1000)
  const gpu = gpuMeasurements(initialGpu, endGpu)
  const result = benchmarkResultSchema.parse({
    config,
    reactMode,
    userTimingMeasureCount,
    wallMs,
    cpuPercent: ((cpu.user + cpu.system) / (wallMs * 1000)) * 100,
    requestedMessages,
    generatedMessages: load.generated(),
    processedMessages: count,
    processedAfterDrain: processed() - initialProcessed,
    achievedRate: count / (wallMs / 1000),
    generatorMissedMessages: Math.max(0, requestedMessages - load.generated()),
    rssBaselineBytes: baselineMemory.rss,
    rssMedianBytes: percentile(
      samples.map((entry) => entry.rssBytes),
      0.5,
    ),
    rssPeakBytes: Math.max(baselineMemory.rss, ...samples.map((entry) => entry.rssBytes)),
    heapPeakBytes: Math.max(baselineMemory.heapUsed, ...samples.map((entry) => entry.heapBytes)),
    eventLoopLagP50Ms: percentile(lags, 0.5),
    eventLoopLagP95Ms: percentile(lags, 0.95),
    eventLoopLagMaxMs: Math.max(0, ...lags),
    gpu,
    samples,
    retainedMessages: channels.reduce(
      (total, channel) => total + (app.watchedMessagesStore.get().get(channel.id)?.length ?? 0),
      0,
    ),
    nativeWindow: { width: bounds.width, height: bounds.height },
    bunVersion: Bun.version,
    timestamp: new Date().toISOString(),
    compositor: process.env.TWIRCHAT_QA_COMPOSITOR,
    hardwareGpuCountersAvailable: gpu.some((device) => typeof device.engines.gfx === 'number'),
    paintedTextVerified: true,
    provenance,
    termination,
  })
  if (
    config.rate > 0 &&
    termination === 'completed' &&
    !result.gpu.some((device) => (device.engines.gfx ?? 0) > 0)
  )
    throw new Error(
      'No active per-process GPU graphics counter; refusing a software-rendered benchmark.',
    )
  await Bun.write(join(directory, 'benchmark-result.json'), JSON.stringify(result, null, 2))
  if (process.env.TWIRCHAT_QA_COMPOSITOR === 'xvfb') await captureGuiQaDisplay('benchmark-after')
  console.log(
    JSON.stringify({
      ok: true,
      channels: config.channels,
      target: config.rate,
      panes: config.panes,
      cpu: result.cpuPercent,
      rate: result.achievedRate,
      rssMiB: result.rssPeakBytes / 1024 ** 2,
      gpu: result.gpu,
      termination,
    }),
  )
} finally {
  await stopProfile()
  stopMessages()
  await manager.quit()
  backend.dispose?.()
}
process.exit(0)
