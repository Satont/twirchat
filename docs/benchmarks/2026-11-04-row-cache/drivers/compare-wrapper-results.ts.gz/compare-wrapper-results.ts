import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { resolve, sep } from 'node:path'

import { z } from '/home/satont/.codex/worktrees/performance-next/chat/packages/desktop/node_modules/zod'
import { benchmarkProvenanceSchema } from '/home/satont/.codex/worktrees/performance-next/chat/packages/desktop/scripts/bench-metrics'

const boxSchema = z.object({ x: z.number(), y: z.number(), width: z.number(), height: z.number() })
const elementSchema = z.object({
  type: z.string(),
  testId: z.string().nullable(),
  text: z.string().nullable(),
  source: z.string().nullable(),
  bounds: boxSchema,
})
const snapshotSchema = z.object({
  width: z.number(),
  viewport: boxSchema,
  rows: z.array(z.object({ type: z.string(), bounds: boxSchema })),
  elements: z.array(elementSchema),
  glyph: z.object({
    text: z.string(),
    bounds: boxSchema,
    baselineSelection: z.string(),
    selectionAfterHover: z.string(),
    beforeSha256: z.string(),
    afterSha256: z.string(),
    changedPixels: z.literal(0),
  }),
})
const resultSchema = z.object({
  ok: z.literal(true),
  scriptSha256: z.string(),
  provenance: benchmarkProvenanceSchema,
  nativeManifest: z.object({ version: z.string(), sha256: z.string(), patchDigest: z.string() }),
  compositor: z.literal('xvfb'),
  display: z.object({ width: z.string(), height: z.string() }),
  measurement: z.object({
    interactions: z.array(
      z.object({ width: z.number(), height: z.number(), compactSemantic: snapshotSchema }),
    ),
  }),
})
const beforePath = z.string().min(1).parse(process.argv[2])
const afterPath = z.string().min(1).parse(process.argv[3])
const beforeSession = resolve(z.string().min(1).parse(process.argv[4]))
const afterSession = resolve(z.string().min(1).parse(process.argv[5]))
const output = z.string().min(1).parse(process.argv[6])
const before = resultSchema.parse(await Bun.file(beforePath).json())
const after = resultSchema.parse(await Bun.file(afterPath).json())
assert.equal(before.scriptSha256, after.scriptSha256, 'Exact same frozen semantic driver')
assert.deepEqual(before.display, after.display, 'Identical private framebuffer dimensions')
assert.equal(before.display.width, '1280')
assert.equal(before.display.height, '1500')
assert.deepEqual(
  before.measurement.interactions.map(({ width, height }) => ({ width, height })),
  after.measurement.interactions.map(({ width, height }) => ({ width, height })),
)
const digestCache = new Map<string, string>()
async function sourceDigest(source: string, session: string) {
  assert(source.startsWith('<session>/'), 'Only retained private session image paths are accepted')
  const path = resolve(session, source.slice('<session>/'.length))
  assert(
    path.startsWith(`${session}${sep}`),
    'Image source remains inside retained private session',
  )
  const cached = digestCache.get(path)
  if (cached) return cached
  const sha256 = createHash('sha256')
    .update(await Bun.file(path).bytes())
    .digest('hex')
  digestCache.set(path, sha256)
  return sha256
}
const stages = []
for (let index = 0; index < before.measurement.interactions.length; index++) {
  const baseline = before.measurement.interactions[index]?.compactSemantic
  const final = after.measurement.interactions[index]?.compactSemantic
  assert(baseline && final)
  const geometry = (snapshot: z.infer<typeof snapshotSchema>) => ({
    width: snapshot.width,
    viewport: snapshot.viewport,
    rows: snapshot.rows,
    glyph: snapshot.glyph,
    elements: snapshot.elements.map(({ source: _source, ...element }) => element),
  })
  const imagePairs = []
  for (let elementIndex = 0; elementIndex < baseline.elements.length; elementIndex++) {
    const b = baseline.elements[elementIndex],
      f = final.elements[elementIndex]
    if (b?.type !== 'img' && f?.type !== 'img') continue
    assert(
      b?.type === 'img' && f?.type === 'img' && b.source && f.source,
      'Paired visible images retain inspectable sources',
    )
    const baselineSha256 = await sourceDigest(b.source, beforeSession)
    const finalSha256 = await sourceDigest(f.source, afterSession)
    imagePairs.push({
      index: elementIndex,
      baselineSource: b.source,
      finalSource: f.source,
      baselineSha256,
      finalSha256,
      equalBytes: baselineSha256 === finalSha256,
      equalPathString: b.source === f.source,
    })
  }
  stages.push({
    width: baseline.width,
    elementCount: baseline.elements.length,
    rowCount: baseline.rows.length,
    geometryEquivalent: JSON.stringify(geometry(baseline)) === JSON.stringify(geometry(final)),
    imageBytesEquivalent: imagePairs.every((pair) => pair.equalBytes),
    cachePathStringsEquivalent: imagePairs.every((pair) => pair.equalPathString),
    imagePairs,
  })
}
const summary = {
  geometryEquivalent: stages.every((stage) => stage.geometryEquivalent),
  imageBytesEquivalent: stages.every((stage) => stage.imageBytesEquivalent),
  cachePathStringsEquivalent: stages.every((stage) => stage.cachePathStringsEquivalent),
  interpretation:
    'Derived geometry and exact retained image-byte equivalence. Literal source-path comparison remains separately preserved; no assertion threshold or raw snapshot was changed.',
  before: {
    result: beforePath,
    session: beforeSession,
    provenance: before.provenance,
    nativeManifest: before.nativeManifest,
  },
  after: {
    result: afterPath,
    session: afterSession,
    provenance: after.provenance,
    nativeManifest: after.nativeManifest,
  },
  driverSha256: before.scriptSha256,
  stages,
}
await Bun.write(output, `${JSON.stringify(summary, null, 2)}\n`)
console.log(
  JSON.stringify(
    {
      geometryEquivalent: summary.geometryEquivalent,
      imageBytesEquivalent: summary.imageBytesEquivalent,
      cachePathStringsEquivalent: summary.cachePathStringsEquivalent,
      stages: stages.map(({ imagePairs, ...stage }) => ({
        ...stage,
        imagePairs: imagePairs.length,
        differingCachePathStrings: imagePairs.filter((pair) => !pair.equalPathString).length,
      })),
    },
    null,
    2,
  ),
)
