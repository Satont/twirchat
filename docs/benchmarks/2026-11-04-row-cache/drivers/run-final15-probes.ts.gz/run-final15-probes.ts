import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'

import { readBenchmarkProvenance } from '/home/satont/.codex/worktrees/performance-next/chat/packages/desktop/scripts/bench-metrics'

const repository = '/home/satont/.codex/worktrees/performance-next/chat'
const scratch = '/home/satont/.cache/twirchat/row-qa'
const sha = async (path: string) =>
  createHash('sha256')
    .update(await Bun.file(path).bytes())
    .digest('hex')
const native = `${repository}/packages/desktop/dist/native/gpuix.linux-x64.node`
const probes = [
  { label: 'lifecycle', timeout: 75, path: 'native/gpuix/probes/window-lifecycle.ts' },
  { label: 'hotkeys', timeout: 90, path: 'native/gpuix/probes/hotkey-capture.ts' },
  { label: 'drags', timeout: 100, path: 'scripts/qa-drag-interactions.tsx' },
  { label: 'deferred', timeout: 60, path: 'scripts/qa-deferred-chat-rows.tsx' },
]
async function identity() {
  return {
    provenance: await readBenchmarkProvenance(repository),
    nativeSha256: await sha(native),
    nativeManifest: await Bun.file(`${native}.json`).json(),
    probeSha256: await Promise.all(
      probes.map(async (probe) => ({
        path: probe.path,
        sha256: await sha(`${repository}/packages/desktop/${probe.path}`),
      })),
    ),
  }
}
const before = await identity()
assert.equal(
  before.provenance.sourceHash,
  '95b51427f343298b5ce21840822790a3197e0af670b94d5b7c241ea36ff69974',
)
assert.equal(
  before.nativeSha256,
  'c29461a214f44b8f4b5696883b81db9613b611b0f07d8a7dfeb680b6cc7fb9c5',
)
const commands = []
try {
  for (const probe of probes) {
    assert.deepEqual(await identity(), before, 'Source, native and probes frozen before GUI')
    const args = [
      'bun',
      'run',
      '--cwd',
      'packages/desktop',
      'qa:gui',
      '--node-env',
      'production',
      '--timeout',
      String(probe.timeout),
      '--artifacts',
      `/home/satont/.cache/th/row15-${probe.label}`,
      '--',
      'bun',
      probe.path,
    ]
    const child = Bun.spawn(args, { cwd: repository, stdout: 'pipe', stderr: 'pipe' })
    const logs = Promise.all([new Response(child.stdout).text(), new Response(child.stderr).text()])
    const exitCode = await child.exited
    const [stdout, stderr] = await logs
    await Bun.write(`${scratch}/final15-${probe.label}.log`, `STDOUT\n${stdout}\nSTDERR\n${stderr}`)
    commands.push({
      ...probe,
      args,
      exitCode,
      session: stdout.match(/GUI QA isolated session: ([^\n]+)/)?.[1] ?? null,
    })
    console.log(JSON.stringify(commands.at(-1)))
    assert.equal(exitCode, 0, `${probe.label} GUI failed; stopping without source changes`)
    assert.deepEqual(await identity(), before, 'Source, native and probes frozen after GUI')
  }
} finally {
  const after = await identity()
  await Bun.write(
    `${scratch}/final15-four-probes-proof.json`,
    JSON.stringify(
      { before, after, unchanged: JSON.stringify(before) === JSON.stringify(after), commands },
      null,
      2,
    ),
  )
}
