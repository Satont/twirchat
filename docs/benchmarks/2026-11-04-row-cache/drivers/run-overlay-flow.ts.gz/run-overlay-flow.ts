import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { mkdir } from 'node:fs/promises'

import { z } from '/home/satont/.codex/worktrees/performance-next/chat/packages/desktop/node_modules/zod'
import { readBenchmarkProvenance } from '/home/satont/.codex/worktrees/performance-next/chat/packages/desktop/scripts/bench-metrics'

const repository = '/home/satont/.codex/worktrees/performance-next/chat'
const scratch = '/home/satont/.cache/twirchat/row-qa'
const driver = `${scratch}/qa-cached-flow-overlay-v2.ts`
const driverSha256 = 'f5e4094d560e6c96b8370f84dd923825660f34ba8734f185c6132cff0ba3132f'
const label = z
  .string()
  .regex(/^[a-z0-9-]{1,24}$/u)
  .parse(process.argv[2])
const artifact = `/home/satont/.cache/th/${label}`
const native = `${repository}/packages/desktop/dist/native/gpuix.linux-x64.node`
const sha = async (path: string) =>
  createHash('sha256')
    .update(await Bun.file(path).bytes())
    .digest('hex')
const manifestSchema = z
  .object({
    version: z.string(),
    sha256: z.string(),
    patchDigest: z.string(),
    size: z.number(),
    apiVersion: z.literal(3),
  })
  .passthrough()
async function identity() {
  const nativeManifest = manifestSchema.parse(await Bun.file(`${native}.json`).json())
  const nativeSha256 = await sha(native)
  assert.equal(nativeSha256, nativeManifest.sha256, 'Actual addon matches its sidecar')
  assert.equal((await Bun.file(native).stat()).size, nativeManifest.size)
  assert.equal(await sha(driver), driverSha256, 'Frozen strict overlay driver')
  return {
    provenance: await readBenchmarkProvenance(repository),
    nativeSha256,
    nativeManifest,
    driverSha256,
  }
}
const before = await identity()
await mkdir(artifact)
const args = [
  'bun',
  'run',
  '--cwd',
  'packages/desktop',
  'qa:gui',
  '--node-env',
  'production',
  '--display-width',
  '1280',
  '--display-height',
  '1500',
  '--timeout',
  '120',
  '--artifacts',
  artifact,
  '--',
  'bun',
  driver,
  JSON.stringify(before.provenance),
]
let exitCode: number | null = null
let session: string | null = null
try {
  await Bun.write(
    `${scratch}/${label}-command.json`,
    JSON.stringify({ args, before, guiOnly: true, sourceSwitching: false }, null, 2),
  )
  const child = Bun.spawn(args, { cwd: repository, stdout: 'pipe', stderr: 'pipe' })
  const output = Promise.all([new Response(child.stdout).text(), new Response(child.stderr).text()])
  exitCode = await child.exited
  const [stdout, stderr] = await output
  await Bun.write(`${scratch}/${label}.log`, `STDOUT\n${stdout}\nSTDERR\n${stderr}`)
  session = stdout.match(/GUI QA isolated session: ([^\n]+)/u)?.[1] ?? null
  assert.equal(exitCode, 0, `Overlay GUI failed; inspect ${scratch}/${label}.log`)
  console.log(
    JSON.stringify({
      ok: true,
      session,
      result: session ? `${session}/cached-flow-result.json` : null,
      native: before.nativeManifest.version,
      sourceHash: before.provenance.sourceHash,
      driverSha256,
    }),
  )
} finally {
  const after = await identity()
  await Bun.write(
    `${scratch}/${label}-proof.json`,
    JSON.stringify(
      {
        before,
        after,
        unchanged: JSON.stringify(before) === JSON.stringify(after),
        args,
        exitCode,
        session,
        guiOnly: true,
      },
      null,
      2,
    ),
  )
  assert.deepEqual(
    after,
    before,
    'Source, installed artifact and driver unchanged across isolated GUI',
  )
}
