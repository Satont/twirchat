import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { unlink } from 'node:fs/promises'
import { join } from 'node:path'
import { readBenchmarkProvenance } from '/home/satont/.codex/worktrees/performance-next/chat/packages/desktop/scripts/bench-metrics'
import { parseNativeSourceManifest } from '/home/satont/.codex/worktrees/performance-next/chat/packages/desktop/scripts/build-gpuix-native'
interface Saved {path:string; bytes:Uint8Array}
const root='/home/satont/.codex/worktrees/performance-next/chat', work='/home/satont/.cache/twirchat/row-qa'
const native='packages/desktop/dist/native/gpuix.linux-x64.node'
const finalHash='3918efb311f05dab85d18f4295a6c52fcfe92c77b041a6b5ab867dcce9007f11', baseHash='7726a43b8af0351d1025e8b283f923a3250731e90ee8b8ae0e86f5c4c5fab7f5'
const finalNative='f50c0f2627b407e74bfaa124d8a7f03bb84ccb315e01e0e07f653712942735cd', baseNative='9167fe97d8be98517296d008f9c5bbaeb3f056e5e26159523db3e6147d47682f'
const tracked=['packages/desktop/native/gpuix/README.md','packages/desktop/native/gpuix/source.json']
const manifest=parseNativeSourceManifest(await Bun.file(join(root,tracked[1]!)).json())
assert.equal(manifest.version,'0.11.0-twirchat.14')
const extras=manifest.patches.slice(21).map(p=>'packages/desktop/native/gpuix/'+p.path)
assert.equal(extras.length,6)
const saved:Saved[]=[]
for(const path of [...tracked,...extras,native,native+'.json']) {const bytes=await Bun.file(join(root,path)).bytes(); saved.push({path,bytes}); await Bun.write(join(work,'source14-before-repeats',path),bytes)}
await Bun.write(join(work,'source14-before-repeats/index.json'),JSON.stringify(saved.map(s=>({path:s.path,sha256:createHash('sha256').update(s.bytes).digest('hex')})),null,2)+'\n')
async function frozen(hash:string,sha:string){assert.equal((await readBenchmarkProvenance(root)).sourceHash,hash); assert.equal(createHash('sha256').update(await Bun.file(join(root,native)).bytes()).digest('hex'),sha)}
async function restore(){for(const s of saved)await Bun.write(join(root,s.path),s.bytes); await frozen(finalHash,finalNative)}
async function baseline(){for(const path of tracked){const p=Bun.spawn(['git','show',`HEAD:${path}`],{cwd:root,stdout:'pipe',stderr:'inherit'});const bytes=await new Response(p.stdout).arrayBuffer();assert.equal(await p.exited,0);await Bun.write(join(root,path),bytes)}for(const path of extras)await unlink(join(root,path));for(const suffix of ['','.json'])await Bun.write(join(root,native+suffix),Bun.file(join(work,'base-native/gpuix.linux-x64.node'+suffix)));await frozen(baseHash,baseNative)}
const cases=['c1-r0-p1','c10-r0-p1','c10-r100-p1','c10-r1000-p1','c10-r5000-p1']
await frozen(finalHash,finalNative)
try {
 for(let rep=1;rep<=3;rep++)for(const version of ['final14','baseline10']){
  if(version==='final14')await restore();else await baseline()
  const hash=version==='final14'?finalHash:baseHash,sha=version==='final14'?finalNative:baseNative
  await Bun.write(join(work,`repeat-${version}-${rep}-identity.json`),JSON.stringify({provenance:await readBenchmarkProvenance(root),nativeManifest:await Bun.file(join(root,native+'.json')).json()},null,2)+'\n')
  for(const name of cases){
   const output=`/home/satont/.cache/th/r14r/${version==='final14'?'f':'b'}${rep}-${name}`
   assert.equal(await Bun.file(join(output,'results.json')).exists(),false)
   await frozen(hash,sha)
   console.log(JSON.stringify({version,rep,case:name,state:'started',utc:new Date().toISOString()}))
   const p=Bun.spawn([process.execPath,'run','--cwd','packages/desktop','bench:chat','--scenario',name,'--mode','development','--duration','12','--warmup','3','--output',output],{cwd:root,stdout:'pipe',stderr:'pipe'})
   const [out,err,code]=await Promise.all([new Response(p.stdout).text(),new Response(p.stderr).text(),p.exited])
   await Bun.write(join(work,`repeat-${version}-${rep}-${name}.log`),out+'\n'+err)
   assert.equal(code,0);await frozen(hash,sha)
   console.log(JSON.stringify({version,rep,case:name,state:'passed',utc:new Date().toISOString()}))
  }
 }
} finally { await restore(); console.log(JSON.stringify({restored:true,provenance:await readBenchmarkProvenance(root)})) }
