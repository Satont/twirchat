import assert from 'node:assert/strict'

import type { z } from '/home/satont/.codex/worktrees/performance-next/chat/packages/desktop/node_modules/zod'

import { readDataset, metrics, type datasetSchema } from './load-data'

type Dataset = z.infer<typeof datasetSchema>
const root = '/home/satont/.cache/th'
const scratch = '/home/satont/.cache/twirchat/row-qa'
const sources = {
  b: '7726a43b8af0351d1025e8b283f923a3250731e90ee8b8ae0e86f5c4c5fab7f5',
  f: '3918efb311f05dab85d18f4295a6c52fcfe92c77b041a6b5ab867dcce9007f11',
}
async function load(version: 'b' | 'f', rep: number, cohort: 'original' | 'balanced') {
  const path =
    cohort === 'original'
      ? `${root}/r14r/${version}${rep}-c10-r1000-p1/results.json`
      : `${root}/r14b/${version}${rep}/results.json`
  const data: Dataset = await readDataset(path)
  assert.equal(data.provenance.sourceHash, sources[version])
  assert.equal(data.results.length, 1)
  const result = data.results[0]
  assert(result)
  assert.deepEqual(result.provenance, data.provenance)
  assert.deepEqual(result.config, {
    channels: 10,
    rate: 1000,
    panes: 1,
    warmupSeconds: 3,
    durationSeconds: 12,
  })
  assert.deepEqual(result.nativeWindow, { width: 1200, height: 800 })
  assert.equal(result.retainedMessages, 2000)
  assert.equal(result.reactMode, 'development')
  assert.equal(result.bunVersion, '1.4.4')
  assert.equal(result.compositor, 'weston')
  assert.equal(result.termination, 'completed')
  const samples = result.samples
  const first = samples[0],
    last = samples.at(-1)
  assert(first && last)
  const peakSample = samples.reduce(
    (peak, sample) => (sample.rssBytes > peak.rssBytes ? sample : peak),
    first,
  )
  const thresholds = [550, 575, 600].map((thresholdMiB) => {
    const high = samples.filter((sample) => sample.rssBytes > thresholdMiB * 1048576)
    return {
      thresholdMiB,
      samplesAbove: high.length,
      totalSamples: samples.length,
      sampleTimesMs: high.map((sample) => sample.elapsedMs),
      observedFirstLastSpanMs:
        high.length > 1 ? (high.at(-1)?.elapsedMs ?? 0) - (high[0]?.elapsedMs ?? 0) : 0,
      note: 'Sample points/span do not prove continuous residence duration.',
    }
  })
  const heapDrops = samples.flatMap((sample, index) => {
    const previous = samples[index - 1]
    return previous && previous.heapBytes - sample.heapBytes > 15 * 1048576
      ? [
          {
            elapsedMs: sample.elapsedMs,
            dropMiB: (previous.heapBytes - sample.heapBytes) / 1048576,
            rssMiB: sample.rssBytes / 1048576,
          },
        ]
      : []
  })
  return {
    cohort,
    version,
    rep,
    path,
    provenance: data.provenance,
    environment: data.environment,
    metrics: metrics(result),
    observations: {
      sampleCount: samples.length,
      rssSampleMinMiB: Math.min(...samples.map((sample) => sample.rssBytes)) / 1048576,
      heapSampleMinMiB: Math.min(...samples.map((sample) => sample.heapBytes)) / 1048576,
      lastSample: {
        elapsedMs: last.elapsedMs,
        rssMiB: last.rssBytes / 1048576,
        heapMiB: last.heapBytes / 1048576,
      },
      peakSample: {
        elapsedMs: peakSample.elapsedMs,
        rssMiB: peakSample.rssBytes / 1048576,
        heapMiB: peakSample.heapBytes / 1048576,
        gpu: peakSample.gpu,
      },
      fellAfterSampledPeak: last.rssBytes < peakSample.rssBytes,
      thresholds,
      heapDropsOver15MiB: heapDrops,
      gcTelemetryAvailable: false,
      nativeFrameOrMutationCountersAvailable: false,
    },
  }
}
function range(values: number[]) {
  const sorted = [...values].sort((a, b) => a - b)
  const midpoint = sorted.length / 2
  const median =
    sorted.length % 2
      ? sorted[Math.floor(midpoint)]
      : ((sorted[midpoint - 1] ?? NaN) + (sorted[midpoint] ?? NaN)) / 2
  assert(median !== undefined && Number.isFinite(median))
  return { median, min: Math.min(...values), max: Math.max(...values), values }
}
type Row = Awaited<ReturnType<typeof load>>
function compare(baseline: Row[], final: Row[]) {
  const first = baseline[0]
  assert(first)
  const comparisons = Object.fromEntries(
    Object.keys(first.metrics).map((key) => {
      const values = (rows: Row[]) =>
        rows.map((row) => {
          const value: unknown = Reflect.get(row.metrics, key)
          assert(typeof value === 'number')
          return value
        })
      const b = range(values(baseline)),
        f = range(values(final))
      return [
        key,
        {
          baseline: b,
          final: f,
          deltaPercent: b.median === 0 ? null : (f.median / b.median - 1) * 100,
        },
      ]
    }),
  )
  const flags = Object.entries(comparisons)
    .filter(
      ([key, value]) =>
        ['cpuPercent', 'rssMedianMiB', 'rssPeakMiB'].includes(key) &&
        value.deltaPercent !== null &&
        value.deltaPercent > 5,
    )
    .map(([metric]) => metric)
  return { nPerVersion: baseline.length, comparisons, flags }
}
const originalB = await Promise.all([1, 2, 3].map((rep) => load('b', rep, 'original'))),
  originalF = await Promise.all([1, 2, 3].map((rep) => load('f', rep, 'original')))
const balancedB = await Promise.all([1, 2, 3].map((rep) => load('b', rep, 'balanced'))),
  balancedF = await Promise.all([1, 2, 3].map((rep) => load('f', rep, 'balanced')))
const original = compare(originalB, originalF),
  balanced = compare(balancedB, balancedF),
  pooled = compare([...originalB, ...balancedB], [...originalF, ...balancedF])
const rows = [...originalB, ...originalF, ...balancedB, ...balancedF]
const analysis = {
  case: 'c10-r1000-p1',
  preregistration: await Bun.file(`${scratch}/balanced14-preregistration.json`).json(),
  units: 'CPU percent of one core, memory MiB, lag ms, throughput messages/s',
  original,
  balanced,
  pooled,
  decisionFlags: { balanced: balanced.flags, pooled: pooled.flags },
  all12PeakRows: rows.map(({ cohort, version, rep, metrics, observations }) => ({
    cohort,
    version,
    rep,
    rssPeakMiB: metrics.rssPeakMiB,
    rssMedianMiB: metrics.rssMedianMiB,
    heapPeakMiB: metrics.jsHeapPeakMiB,
    lagP95Ms: metrics.lagP95Ms,
    lagMaxMs: metrics.lagMaxMs,
    samplesAbove600MiB: observations.thresholds.find((entry) => entry.thresholdMiB === 600)
      ?.samplesAbove,
  })),
  rows,
  interpretation:
    'Original3v3, preregistered counterbalanced3v3 and pooled6v6 remain separate. Initial single matrix is not pooled. All peaks and original>5% flag remain visible. No GC causality, spike elimination, leak freedom or automatic acceptance claim; decision flags require root review.',
}
await Bun.write(`${scratch}/balanced14-analysis.json`, JSON.stringify(analysis, null, 2))
console.log(
  JSON.stringify(
    {
      original,
      balanced,
      pooled,
      decisionFlags: analysis.decisionFlags,
      all12PeakRows: analysis.all12PeakRows,
    },
    null,
    2,
  ),
)
