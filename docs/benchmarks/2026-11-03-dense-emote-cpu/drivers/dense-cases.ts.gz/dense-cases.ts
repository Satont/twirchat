import {createHash} from 'node:crypto'
import {mkdir,rm} from 'node:fs/promises'
import {join} from 'node:path'
const root='/home/satont/.codex/worktrees/animated-emote-resources/chat'
const desktop=join(root,'packages/desktop')
const stage=process.argv[2]
if(!stage || !['before','after','smoke','after-smoke','bindings-smoke','observer','after17','observer17'].includes(stage))throw new Error('stage required')
const output=`/tmp/twirchat-dense-cpu-${stage}`
const bun='/home/satont/.local/share/mise/installs/bun/1.4.4/bin/bun'
await mkdir(output,{recursive:true})
const {readBenchmarkProvenance}=await import(join(desktop,'scripts/bench-metrics.ts'))
const provenance=await readBenchmarkProvenance(root)
const fixture=join(desktop,'scripts/qa-emote-resources.tsx')
const scriptSha=createHash('sha256').update(await Bun.file(fixture).bytes()).digest('hex')
await Bun.write(join(output,'dense-provenance.json'),JSON.stringify({provenance,scriptSha},null,2))
for(const activation of ['focused','unfocused']){
 for(let index=1;index<=(stage.endsWith('smoke')||stage.startsWith('observer')?1:3);index++){
  const name=`dense-${activation}-${index}`
  const config={case:'idle',preset:'dense',activation,backgroundAnimation:true,durationSeconds:stage.endsWith('smoke')?8:20,warmupSeconds:5,...(stage.startsWith('observer')?{sampleGpuDuringMeasurement:false}:{})}
  console.log(`START ${name}`)
  const artifacts=join(output,name)
  const log=Bun.file(join(output,`${name}.log`))
  const child=Bun.spawn([bun,'run','qa:gui','--node-env','production','--compositor','weston','--weston-shell','desktop','--weston-controls','--display-width','1280','--display-height','1500','--timeout','110','--artifacts',artifacts,'--',bun,'scripts/qa-emote-resources.tsx',JSON.stringify(config),JSON.stringify(provenance)],{cwd:desktop,env:{...process.env,PATH:`${join(bun,'..')}:${process.env.PATH}`},stdout:log,stderr:log})
  if(await child.exited!==0){console.log((await log.text()).slice(-14000));throw new Error(`${name} failed`)}
  const sessions=[...new Bun.Glob('twirchat-gui-qa-*/emote-resources-result.json').scanSync({cwd:artifacts})]
  if(sessions.length!==1)throw new Error('Result session missing or repeated')
  const path=sessions[0]
  if(!path)throw new Error('Missing report')
  const report=await Bun.file(join(artifacts,path)).json()
  await Bun.write(join(output,`${name}.json`),JSON.stringify(report,null,2))
  const session=join(artifacts,path,'..')
  await Promise.all(['runtime','profile','framebuffer','home','cache','config'].map(part=>rm(join(session,part),{recursive:true,force:true})))
  const after=await readBenchmarkProvenance(root)
  if(after.sourceHash!==provenance.sourceHash || createHash('sha256').update(await Bun.file(fixture).bytes()).digest('hex')!==scriptSha)throw new Error('Frozen inputs changed')
  console.log(`DONE ${name}: CPU ${report.measurement.cpuPercent.toFixed(2)}%, fps ${(report.measurement.totalPresentsPerSecond??report.measurement.nativeFramesPerSecond).toFixed(2)}, RSS ${(report.measurement.rssMedianBytes/1048576).toFixed(1)} MiB`)
 }
}
console.log(`DENSE ${stage.toUpperCase()} COMPLETE`)
