import {createHash} from 'node:crypto'
import {join} from 'node:path'
import type {EmoteCatalogEntry} from '/home/satont/.codex/worktrees/animated-emote-resources/chat/packages/shared/protocol.ts'
import {DEFAULT_EMOTE_PREFERENCES,type EmoteProvider} from '/home/satont/.codex/worktrees/animated-emote-resources/chat/packages/desktop/src/services/provider-emotes.ts'
import {ProviderRuntime} from '/home/satont/.codex/worktrees/animated-emote-resources/chat/packages/desktop/src/services/provider-runtime.ts'
const root='/home/satont/.codex/worktrees/animated-emote-resources/chat'
const {readBenchmarkProvenance}=await import(join(root,'packages/desktop/scripts/bench-metrics.ts'))
const output=process.argv[2]
if(!output)throw new Error('output required')
const provenance=await readBenchmarkProvenance(root)
const providers:EmoteProvider[]=['twitch','seventv','bttv','ffz']
const channels=23, emotesPerChannel=1500,durationMs=12000
const catalogs=new Map<string,EmoteCatalogEntry[]>()
for(let channel=0;channel<channels;channel++)catalogs.set(`channel-${channel}`,Array.from({length:emotesPerChannel},(_,index):EmoteCatalogEntry=>{
 const provider=providers[index%providers.length]??'twitch'
 return {id:`${channel}-${index}`,name:`Emote${index}`,alias:`Emote${index}`,source:provider==='twitch'?'channel':provider,provider,imageUrl:`https://example.invalid/emote/${channel}/${index}/1x.webp`,aspectRatio:1,animated:true,zeroWidth:false}
}))
let fetches=0
const preferences=JSON.stringify(DEFAULT_EMOTE_PREFERENCES)
const runtime=new ProviderRuntime({readPreferences:()=>preferences,accounts:()=>[],resolve:async(_platform,login)=>({platformUserId:login,login}),native:async()=>[],sevenTv:()=>undefined,catalog:async(_platform,channel)=>{fetches++;return catalogs.get(channel)??[]},badges:async()=>({users:{}}),sevenTvUser:async()=>undefined,presence:async()=>{}})
await Promise.all([...catalogs.keys()].map(channel=>runtime.warm('twitch',channel)))
for(const channel of catalogs.keys())runtime.setJoined(channel,'twitch',channel)
runtime.start()
await Bun.sleep(2000)
const rss:number[]=[],heap:number[]=[]
const sample=setInterval(()=>{const mem=process.memoryUsage();rss.push(mem.rss);heap.push(mem.heapUsed)},250)
const cpuStart=process.cpuUsage(),start=performance.now()
await Bun.sleep(durationMs)
const wallMs=performance.now()-start,cpu=process.cpuUsage(cpuStart)
clearInterval(sample);runtime.stop()
const after=await readBenchmarkProvenance(root)
if(after.sourceHash!==provenance.sourceHash)throw new Error('Sources changed')
await Bun.write(output,JSON.stringify({provenance,scriptSha256:createHash('sha256').update(await Bun.file(import.meta.path).bytes()).digest('hex'),channels,emotesPerChannel,durationMs,wallMs,fetches,cpuPercent:100*(cpu.user+cpu.system)/(wallMs*1000),rssMedianBytes:rss.toSorted((a,b)=>a-b)[Math.floor(rss.length/2)],rssPeakBytes:Math.max(...rss),heapPeakBytes:Math.max(...heap),timestamp:new Date().toISOString()},null,2))
console.log(output)
