import {mkdir} from 'node:fs/promises'
import {join} from 'node:path'
const root='/home/satont/.codex/worktrees/animated-emote-resources/chat',desktop=join(root,'packages/desktop')
const bun='/home/satont/.local/share/mise/installs/bun/1.4.4/bin/bun',destination=join(desktop,'dist/native/gpuix.linux-x64.node')
const backup='/tmp/twirchat-dense-cpu-final-native'
const index=process.argv[2]??'1'
await mkdir(backup,{recursive:true})
for(const suffix of ['', '.json'])await Bun.write(join(backup,`gpuix.linux-x64.node${suffix}`),Bun.file(`${destination}${suffix}`))
try{
 for(const suffix of ['', '.json'])await Bun.write(`${destination}${suffix}`,Bun.file(`/tmp/twirchat-dense-cpu-before/native/gpuix.linux-x64.node${suffix}`))
 const child=Bun.spawn([bun,'run','bench:chat','--scenario','c50-r5000-p4','--mode','production','--duration','30','--output',`/tmp/twirchat-dense-cpu-before/control-current-js-${index}`],{cwd:desktop,env:{...process.env,PATH:`${join(bun,'..')}:${process.env.PATH}`},stdout:'inherit',stderr:'inherit'})
 if(await child.exited!==0)throw new Error('Native .6 control failed')
}finally{
 for(const suffix of ['', '.json'])await Bun.write(`${destination}${suffix}`,Bun.file(join(backup,`gpuix.linux-x64.node${suffix}`)))
}
