import { mkdir } from 'node:fs/promises'
import { join } from 'node:path'
import { readBenchmarkProvenance } from '/home/satont/.codex/worktrees/performance-next/chat/packages/desktop/scripts/bench-metrics'

const repository = '/home/satont/.codex/worktrees/performance-next/chat'
const desktop = join(repository, 'packages/desktop')
const label = process.argv[2] ?? 'baseline'
const repetitions = Number(process.argv[3] ?? '1')
const modes = (process.argv[4] ?? 'none,same-row,cross-rows').split(',')
const pointerSweepSeconds = Number(process.argv[5] ?? '2')
const program = process.argv[6] === 'profile' ? 'dist/perf/profile-hover.ts' : 'scripts/qa-emote-resources.tsx'
const root = join('/home/satont/.cache/th', label)
await mkdir(root, { recursive: true })
const provenance = await readBenchmarkProvenance(repository)
await Bun.write(join(root, 'provenance.json'), JSON.stringify(provenance, null, 2))
for (let repetition = 1; repetition <= repetitions; repetition++) {
  for (const pointerMotion of modes) {
    const output = join(root, `${pointerMotion}-${repetition}`)
    const config = { case: 'idle', preset: 'dense', activation: 'focused', pointerMotion, pointerSweepSeconds, warmupSeconds: 5, durationSeconds: 20, backgroundAnimation: true }
    const child = Bun.spawn([process.execPath, 'run', 'qa:gui', '--node-env', 'production', '--compositor', 'weston', '--weston-shell', 'desktop', '--weston-controls', '--display-width', '1280', '--display-height', '1500', '--keep', '--timeout', '65', '--artifacts', output, '--', process.execPath, program, JSON.stringify(config), JSON.stringify(provenance)], { cwd: desktop, stdout: 'pipe', stderr: 'pipe' })
    const [stdout, stderr, code] = await Promise.all([new Response(child.stdout).text(), new Response(child.stderr).text(), child.exited])
    await Bun.write(join(root, `${pointerMotion}-${repetition}.log`), stdout + '\n' + stderr)
    const session = stdout.match(/GUI QA isolated session: (.+)/u)?.[1]
    if (code !== 0 || !session) throw new Error(`Failed ${output}: ${stderr.slice(-3000)}`)
    const result = await Bun.file(join(session, 'emote-resources-result.json')).json()
    await Bun.write(join(root, `${pointerMotion}-${repetition}.json`), JSON.stringify(result, null, 2))
    console.log(JSON.stringify({ label, repetition, pointerMotion, session, measurement: { cpu: result.measurement.cpuPercent, rss: result.measurement.rssMedianBytes, fullDraws: result.measurement.nativeFrames, batches: result.measurement.nativeMutationBatches, calls: result.measurement.pointer?.actualCallsPerSecond } }))
    const current = await readBenchmarkProvenance(repository)
    if (current.sourceHash !== provenance.sourceHash || current.gitHead !== provenance.gitHead) throw new Error('Sources changed during run')
  }
}
