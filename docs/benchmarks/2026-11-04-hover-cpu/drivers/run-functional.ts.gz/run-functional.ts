import { join } from 'node:path'
import { readBenchmarkProvenance } from '/home/satont/.codex/worktrees/performance-next/chat/packages/desktop/scripts/bench-metrics'
const repository = '/home/satont/.codex/worktrees/performance-next/chat'
const label = process.argv[2] ?? 'baseline-functional'
const program = process.argv[3] ?? 'scripts/qa-emote-resources.tsx'
const output = `/home/satont/.cache/th/${label}`
const provenance = await readBenchmarkProvenance(repository)
const config = {case: 'functional', preset: 'dense', warmupSeconds: 3, backgroundAnimation: true}
const arguments_ = program === 'scripts/qa-text-rendering.tsx' ? [JSON.stringify(provenance)] : [JSON.stringify(config), JSON.stringify(provenance)]
const displayHeight = program === 'scripts/qa-text-rendering.tsx' ? '900' : '1500'
const child = Bun.spawn([process.execPath, 'run', 'qa:gui', '--node-env', 'production', '--keep', '--timeout', '120', '--display-width', '1280', '--display-height', displayHeight, '--artifacts', output, '--', process.execPath, program, ...arguments_], {cwd: join(repository, 'packages/desktop'), stdout:'pipe', stderr:'pipe'})
const [stdout,stderr,code] = await Promise.all([new Response(child.stdout).text(),new Response(child.stderr).text(),child.exited])
await Bun.write(`${output}.log`,stdout+'\n'+stderr)
console.log(JSON.stringify({code, session: stdout.match(/GUI QA isolated session: (.+)/u)?.[1]}))
if (code!==0) throw new Error(stderr.slice(-4000))
