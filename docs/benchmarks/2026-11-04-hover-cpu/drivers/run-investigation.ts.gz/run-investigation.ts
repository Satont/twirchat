import { createHash } from 'node:crypto'
import { join } from 'node:path'

import { z } from '/home/satont/.codex/worktrees/performance-next/chat/packages/desktop/node_modules/zod'
import { readBenchmarkProvenance } from '/home/satont/.codex/worktrees/performance-next/chat/packages/desktop/scripts/bench-metrics'

const repository = '/home/satont/.codex/worktrees/performance-next/chat'
const root = '/home/satont/.cache/th'
const label = z.string().regex(/^[a-z][a-z0-9-]{0,7}$/u).parse(process.argv[2])
const scenarios = ['c10-r5000-p1', 'c50-r5000-p1', 'c100-r5000-p4']
const provenance = await readBenchmarkProvenance(repository)
const drivers = []
for (const path of ['scripts/bench-chat.ts', 'scripts/bench-chat-case.tsx', 'scripts/bench-metrics.ts', 'scripts/qa-emote-resources.tsx']) {
  const bytes = new Uint8Array(await Bun.file(join(repository, 'packages/desktop', path)).arrayBuffer())
  drivers.push({ path, sha256: createHash('sha256').update(bytes).digest('hex') })
}
await Bun.write(join(root, `${label}-investigation-provenance.json`), JSON.stringify({ provenance, drivers }, null, 2))
for (let repetition = 1; repetition <= 3; repetition++) {
  for (const scenario of scenarios) {
    const output = join(root, `${label}-${scenario}-${repetition}`)
    if (await Bun.file(join(output, 'results.json')).exists()) throw new Error(`Refusing to overwrite ${output}`)
    const child = Bun.spawn([
      process.execPath, 'run', '--cwd', 'packages/desktop', 'bench:chat',
      '--scenario', scenario, '--mode', 'development', '--duration', '12', '--warmup', '3', '--output', output,
    ], { cwd: repository, stdout: 'inherit', stderr: 'inherit' })
    if (await child.exited !== 0) throw new Error(`Failed ${output}`)
    const current = await readBenchmarkProvenance(repository)
    if (current.sourceHash !== provenance.sourceHash || current.gitHead !== provenance.gitHead) throw new Error('Benchmark sources changed during investigation')
  }
}
