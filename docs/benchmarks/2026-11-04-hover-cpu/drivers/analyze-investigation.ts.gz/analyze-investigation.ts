import { createHash } from 'node:crypto'
import { join } from 'node:path'

import { z } from '/home/satont/.codex/worktrees/performance-next/chat/packages/desktop/node_modules/zod'
import { benchmarkProvenanceSchema } from '/home/satont/.codex/worktrees/performance-next/chat/packages/desktop/scripts/bench-metrics'

const resultSchema = z.object({
  config: z.object({ channels: z.number(), rate: z.literal(5000), panes: z.number(), warmupSeconds: z.literal(3), durationSeconds: z.literal(12) }),
  reactMode: z.literal('development'),
  cpuPercent: z.number(),
  rssMedianBytes: z.number(),
  rssPeakBytes: z.number(),
  heapPeakBytes: z.number(),
  achievedRate: z.number(),
  eventLoopLagP50Ms: z.number(),
  eventLoopLagP95Ms: z.number(),
  eventLoopLagMaxMs: z.number(),
  userTimingMeasureCount: z.number(),
  generatedMessages: z.number(),
  requestedMessages: z.number(),
  processedMessages: z.number(),
  processedAfterDrain: z.number(),
  retainedMessages: z.number(),
  nativeWindow: z.object({ width: z.literal(1200), height: z.literal(800) }),
  provenance: benchmarkProvenanceSchema,
})
const inputSchema = z.object({ provenance: benchmarkProvenanceSchema, results: z.array(z.unknown()) })
const metrics = [
  'cpuPercent', 'rssMedianBytes', 'rssPeakBytes', 'heapPeakBytes', 'achievedRate',
  'eventLoopLagP50Ms', 'eventLoopLagP95Ms', 'eventLoopLagMaxMs',
  'userTimingMeasureCount', 'generatedMessages', 'requestedMessages', 'processedMessages', 'processedAfterDrain',
] satisfies (keyof z.infer<typeof resultSchema>)[]
interface Evidence {
  path: string
  sha256: string
  bytes: number
  provenance: z.infer<typeof benchmarkProvenanceSchema>
}
interface Range {
  median: number
  min: number
  max: number
}
const root = process.argv[2] ?? '/home/satont/.cache/th'
const output = process.argv[3] ?? join(root, 'investigation-analysis.json')
const evidence: Evidence[] = []
const missing: string[] = []
async function read(path: string) {
  const file = Bun.file(join(root, path))
  if (!(await file.exists())) { missing.push(path); return null }
  const bytes = new Uint8Array(await file.arrayBuffer())
  const value: unknown = JSON.parse(new TextDecoder().decode(bytes))
  const data = inputSchema.parse(value)
  evidence.push({ path, sha256: createHash('sha256').update(bytes).digest('hex'), bytes: bytes.length, provenance: data.provenance })
  return data
}
function summarize(rows: z.infer<typeof resultSchema>[]) {
  const summary: Record<string, Range> = {}
  for (const key of [...metrics, 'processedFraction']) {
    const values = rows.map((row) => key === 'processedFraction' ? row.processedMessages / row.requestedMessages : row[key]).filter((value) => typeof value === 'number').toSorted((a, b) => a - b)
    const first = values[0], last = values.at(-1), middle = values[Math.floor(values.length / 2)], previous = values[Math.floor(values.length / 2) - 1]
    if (first === undefined || last === undefined || middle === undefined) continue
    summary[key] = { min: first, max: last, median: values.length % 2 === 0 && previous !== undefined ? (middle + previous) / 2 : middle }
  }
  return summary
}
const beforeMatrix = await read('bm/results.json')
const afterMatrix = await read('fm/results.json')
if (!beforeMatrix || !afterMatrix) throw new Error('Original matrix evidence is required')
const scenarios = []
for (const spec of [{ name: 'c10-r5000-p1', channels: 10, panes: 1 }, { name: 'c50-r5000-p1', channels: 50, panes: 1 }, { name: 'c100-r5000-p4', channels: 100, panes: 4 }]) {
  const initial = []
  const repeated = []
  for (const [label, matrix] of [['bc', beforeMatrix], ['fc', afterMatrix]] satisfies [string, typeof beforeMatrix][]) {
    const candidate = matrix.results.map((value) => resultSchema.safeParse(value)).find((parsed) => parsed.success && parsed.data.config.channels === spec.channels && parsed.data.config.panes === spec.panes)
    if (!candidate?.success) throw new Error(`Original matrix missing ${spec.name}`)
    initial.push({ version: label, row: candidate.data })
    const rows = []
    for (let repetition = 1; repetition <= 3; repetition++) {
      const input = await read(`${label}-${spec.name}-${repetition}/results.json`)
      if (!input) continue
      if (input.provenance.sourceHash !== matrix.provenance.sourceHash) throw new Error(`Investigation source mismatch for ${label}`)
      if (input.results.length !== 1) throw new Error('Expected exactly one investigation case')
      const row = resultSchema.parse(input.results[0])
      if (row.config.channels !== spec.channels || row.config.panes !== spec.panes || row.retainedMessages !== spec.channels * 200) throw new Error('Investigation workload/retention mismatch')
      if (JSON.stringify(row.provenance) !== JSON.stringify(input.provenance)) throw new Error('Row provenance mismatch')
      rows.push(row)
    }
    repeated.push({ version: label, count: rows.length, metrics: summarize(rows), rows })
  }
  const before = repeated.find((entry) => entry.version === 'bc')
  const after = repeated.find((entry) => entry.version === 'fc')
  const changePercent: Record<string, number | null> = {}
  const investigations = []
  for (const key of [...metrics, 'processedFraction']) {
    const first = before?.metrics[key], last = after?.metrics[key]
    if (!first || !last) continue
    const delta = first.median === 0 ? null : ((last.median / first.median) - 1) * 100
    changePercent[key] = delta
    if (['cpuPercent', 'rssMedianBytes', 'rssPeakBytes'].includes(key) && delta !== null && delta > 5) investigations.push(`${key}: repeated median increased ${delta.toFixed(2)}%`)
  }
  scenarios.push({ scenario: spec.name, originalMatrix: initial, repeated, changePercent, investigations })
}
const analysis = {
  status: missing.length ? 'pending' : 'complete',
  generatedAt: new Date().toISOString(),
  units: { cpu: 'percent of one logical core', memory: 'bytes', lag: 'milliseconds' },
  method: 'Three fresh development runs per version/case, 12 seconds measurement plus 3 seconds warmup, 200 retained/channel. Initial matrix samples retained separately and excluded from repeated-run medians.',
  evidence,
  scenarios,
  missing,
}
await Bun.write(output, JSON.stringify(analysis, null, 2))
console.log(JSON.stringify({ output, status: analysis.status, missing, scenarios: scenarios.map(({ scenario, repeated, changePercent, investigations }) => ({ scenario, repeated: repeated.map(({ version, count, metrics }) => ({ version, count, metrics })), changePercent, investigations })) }, null, 2))
if (process.argv.includes('--require-final') && missing.length) process.exitCode = 1
