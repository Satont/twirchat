import { createHash } from 'node:crypto'
import { join } from 'node:path'

import { z } from '/home/satont/.codex/worktrees/performance-next/chat/packages/desktop/node_modules/zod'
import { benchmarkProvenanceSchema } from '/home/satont/.codex/worktrees/performance-next/chat/packages/desktop/scripts/bench-metrics'

const metricNames = [
  'cpuPercent',
  'rssMedianBytes',
  'rssPeakBytes',
  'heapPeakBytes',
  'eventLoopLagP50Ms',
  'eventLoopLagP95Ms',
  'eventLoopLagMaxMs',
  'actualRate',
  'processedFraction',
  'nativeFrames',
  'nativeFramesPerSecond',
  'animationOnlyPresents',
  'totalPresents',
  'nativeMutationBatches',
  'nativeMutationOperations',
  'pointerCallsPerSecond',
  'pointerCompletedFraction',
] satisfies string[]
const resourceSchema = z.object({
  cpuPercent: z.number().nonnegative(),
  rssMedianBytes: z.number().nonnegative(),
  rssPeakBytes: z.number().nonnegative(),
  heapPeakBytes: z.number().nonnegative(),
  eventLoopLagP50Ms: z.number(),
  eventLoopLagP95Ms: z.number(),
  eventLoopLagMaxMs: z.number(),
  wallMs: z.number().positive(),
})
const benchCaseSchema = resourceSchema.extend({
  config: z.object({
    channels: z.number().int(),
    rate: z.number().nonnegative(),
    panes: z.number().int(),
    warmupSeconds: z.number(),
    durationSeconds: z.number(),
  }),
  reactMode: z.enum(['development', 'production']),
  requestedMessages: z.number().nonnegative(),
  generatedMessages: z.number().nonnegative(),
  processedMessages: z.number().nonnegative(),
  achievedRate: z.number().nonnegative(),
  retainedMessages: z.number().nonnegative(),
  nativeWindow: z.object({ width: z.number(), height: z.number() }),
  provenance: benchmarkProvenanceSchema,
})
const benchSchema = z.object({
  environment: z.object({}).passthrough(),
  provenance: benchmarkProvenanceSchema,
  results: z.array(benchCaseSchema).min(1),
})
const nativeManifestSchema = z.object({
  version: z.string(),
  sha256: z.string(),
  patchDigest: z.string(),
  upstreamSHA: z.string(),
  gpuiSHA: z.string(),
  rustToolchain: z.string(),
  target: z.string(),
  size: z.number(),
  apiVersion: z.number(),
})
const pointerSchema = z.object({
  kind: z.enum(['none', 'same-row', 'cross-rows']),
  sweepSeconds: z.number(),
  path: z.unknown(),
  offeredCalls: z.number().nonnegative(),
  dispatchedNativeCalls: z.number().nonnegative(),
  actualCallsPerSecond: z.number().nonnegative(),
})
const probeSchema = z.object({
  ok: z.literal(true),
  config: z.object({}).passthrough(),
  configSha256: z.string(),
  reactMode: z.enum(['production', 'development']),
  scriptSha256: z.string(),
  nativeManifest: nativeManifestSchema,
  provenance: benchmarkProvenanceSchema,
  nativeWindow: z.object({}).passthrough(),
  initialRetainedMessages: z.number(),
  measurement: resourceSchema.extend({
    nativeFrames: z.number(),
    nativeFramesPerSecond: z.number(),
    animationOnlyPresents: z.number(),
    totalPresents: z.number(),
    nativeMutationBatches: z.number(),
    nativeMutationOperations: z.number(),
    actualRate: z.number(),
    retainedMessages: z.number(),
    pointer: pointerSchema.nullable(),
  }),
})
type Input = z.infer<typeof benchSchema> | z.infer<typeof probeSchema>
interface Loaded {
  path: string
  sha256: string
  bytes: number
  data: Input
}
interface Range {
  median: number
  min: number
  max: number
}
type Metrics = Record<string, number>
interface Comparison {
  status: 'complete' | 'pending'
  baseline: { count: number; metrics: Record<string, Range> }
  final: { count: number; metrics: Record<string, Range> }
  changePercent: Record<string, number | null>
  investigations: string[]
}
const root = process.argv[2] ?? '/home/satont/.cache/th'
const destination = process.argv[3] ?? join(root, 'analysis.json')
const requireFinal = process.argv.includes('--require-final')
const inputs: Loaded[] = []
const missing: string[] = []
async function load(path: string, kind: 'bench' | 'probe'): Promise<Loaded | null> {
  const file = Bun.file(join(root, path))
  if (!(await file.exists())) {
    missing.push(path)
    return null
  }
  const bytes = new Uint8Array(await file.arrayBuffer())
  const value: unknown = JSON.parse(new TextDecoder().decode(bytes))
  const data = kind === 'bench' ? benchSchema.parse(value) : probeSchema.parse(value)
  const loaded = {
    path,
    sha256: createHash('sha256').update(bytes).digest('hex'),
    bytes: bytes.length,
    data,
  }
  inputs.push(loaded)
  return loaded
}
function benchMetrics(row: z.infer<typeof benchCaseSchema>): Metrics {
  return {
    cpuPercent: row.cpuPercent,
    rssMedianBytes: row.rssMedianBytes,
    rssPeakBytes: row.rssPeakBytes,
    heapPeakBytes: row.heapPeakBytes,
    eventLoopLagP50Ms: row.eventLoopLagP50Ms,
    eventLoopLagP95Ms: row.eventLoopLagP95Ms,
    eventLoopLagMaxMs: row.eventLoopLagMaxMs,
    actualRate: row.achievedRate,
    processedFraction: row.requestedMessages === 0 ? 1 : row.processedMessages / row.requestedMessages,
  }
}
function probeMetrics(row: z.infer<typeof probeSchema>): Metrics {
  const value = row.measurement
  return {
    cpuPercent: value.cpuPercent,
    rssMedianBytes: value.rssMedianBytes,
    rssPeakBytes: value.rssPeakBytes,
    heapPeakBytes: value.heapPeakBytes,
    eventLoopLagP50Ms: value.eventLoopLagP50Ms,
    eventLoopLagP95Ms: value.eventLoopLagP95Ms,
    eventLoopLagMaxMs: value.eventLoopLagMaxMs,
    actualRate: value.actualRate,
    nativeFrames: value.nativeFrames,
    nativeFramesPerSecond: value.nativeFramesPerSecond,
    animationOnlyPresents: value.animationOnlyPresents,
    totalPresents: value.totalPresents,
    nativeMutationBatches: value.nativeMutationBatches,
    nativeMutationOperations: value.nativeMutationOperations,
    pointerCallsPerSecond: value.pointer?.actualCallsPerSecond ?? 0,
    pointerCompletedFraction:
      !value.pointer || value.pointer.offeredCalls === 0
        ? 1
        : value.pointer.dispatchedNativeCalls / value.pointer.offeredCalls,
  }
}
function summarize(rows: Metrics[]): Record<string, Range> {
  const result: Record<string, Range> = {}
  for (const key of metricNames) {
    const values = rows.flatMap((row) => (typeof row[key] === 'number' ? [row[key]] : [])).toSorted((a, b) => a - b)
    if (!values.length) continue
    const mid = Math.floor(values.length / 2)
    const low = values[0]
    const high = values.at(-1)
    const center = values[mid]
    const previous = values[mid - 1]
    if (low === undefined || high === undefined || center === undefined) throw new Error('Missing sorted metric')
    result[key] = { median: values.length % 2 === 0 && previous !== undefined ? (center + previous) / 2 : center, min: low, max: high }
  }
  return result
}
function compare(before: Metrics[], after: Metrics[]): Comparison {
  const baseline = { count: before.length, metrics: summarize(before) }
  const final = { count: after.length, metrics: summarize(after) }
  const changePercent: Record<string, number | null> = {}
  const investigations: string[] = []
  for (const key of metricNames) {
    const left = baseline.metrics[key]
    const right = final.metrics[key]
    if (!left || !right) continue
    const delta = left.median === 0 ? null : ((right.median / left.median) - 1) * 100
    changePercent[key] = delta
    if (['cpuPercent', 'rssMedianBytes', 'rssPeakBytes'].includes(key) && delta !== null && delta > 5) investigations.push(`${key} median increased ${delta.toFixed(2)}%; investigate and repeat comparable baseline before concluding regression.`)
  }
  for (const [label, summary] of [['baseline', baseline], ['final', final]] satisfies [string, typeof baseline][]) {
    if (summary.metrics.processedFraction && summary.metrics.processedFraction.min < 0.99) investigations.push(`${label} processed under 99% of the offered workload.`)
    if (summary.metrics.pointerCompletedFraction && summary.metrics.pointerCompletedFraction.min < 0.99) investigations.push(`${label} dispatched under 99% of pointer calls.`)
  }
  return { status: before.length && after.length ? 'complete' : 'pending', baseline, final, changePercent, investigations }
}
function benchRows(loaded: Loaded | null): z.infer<typeof benchCaseSchema>[] {
  return loaded && 'results' in loaded.data ? loaded.data.results : []
}
function probeRow(loaded: Loaded | null): z.infer<typeof probeSchema>[] {
  return loaded && 'measurement' in loaded.data ? [loaded.data] : []
}
const baselineMatrix = await load('bm/results.json', 'bench')
const finalMatrix = await load('fm/results.json', 'bench')
const matrix = benchRows(baselineMatrix).map((before) => {
  const after = benchRows(finalMatrix).find((candidate) => JSON.stringify(candidate.config) === JSON.stringify(before.config) && candidate.reactMode === before.reactMode)
  if (after && (JSON.stringify(before.nativeWindow) !== JSON.stringify(after.nativeWindow) || before.retainedMessages !== after.retainedMessages)) throw new Error('Matrix window or retained messages mismatch')
  return { scenario: `c${before.config.channels}-r${before.config.rate}-p${before.config.panes}`, mode: before.reactMode, config: before.config, ...compare([benchMetrics(before)], after ? [benchMetrics(after)] : []) }
})
const targetBefore: Metrics[] = []
const targetAfter: Metrics[] = []
const fastBefore: Metrics[] = []
const fastAfter: Metrics[] = []
for (let repetition = 1; repetition <= 3; repetition++) {
  for (const [prefix, target, fast] of [['baseline', targetBefore, fastBefore], ['final', targetAfter, fastAfter]] satisfies [string, Metrics[], Metrics[]][]) {
    const targetInput = await load(`${prefix}-target-${repetition}/results.json`, 'bench')
    for (const row of benchRows(targetInput)) {
      if (row.reactMode !== 'production' || row.config.channels !== 50 || row.config.rate !== 5000 || row.config.panes !== 4 || row.config.durationSeconds !== 30) throw new Error('Unexpected target workload')
      target.push(benchMetrics(row))
    }
    const fastInput = await load(`${prefix}-fast/cross-rows-${repetition}.json`, 'probe')
    for (const row of probeRow(fastInput)) fast.push(probeMetrics(row))
  }
}
function probeDifferences(before: z.infer<typeof probeSchema>, after: z.infer<typeof probeSchema>) {
  return [
    { field: 'configSha256', before: before.configSha256, after: after.configSha256 },
    { field: 'nativeWindow', before: before.nativeWindow, after: after.nativeWindow },
    { field: 'retainedMessages', before: before.measurement.retainedMessages, after: after.measurement.retainedMessages },
    { field: 'pointerPath', before: before.measurement.pointer?.path, after: after.measurement.pointer?.path },
  ].filter((entry) => JSON.stringify(entry.before) !== JSON.stringify(entry.after))
}
const originalControls = []
for (const mode of ['none', 'same-row']) {
  const before = probeRow(await load(`baseline-controls/${mode}-1.json`, 'probe'))
  const after = probeRow(await load(`final-controls/${mode}-1.json`, 'probe'))
  const first = before[0], last = after[0]
  const mismatches = first && last ? probeDifferences(first, last) : []
  const comparison = compare(before.map(probeMetrics), after.map(probeMetrics))
  originalControls.push({
    mode,
    ...comparison,
    ...(mismatches.length ? {
      status: 'not-comparable',
      changePercent: {},
      investigations: ['Original control pair has different pointer geometry; no before/after change is reported.'],
    } : {}),
    mismatches,
  })
}
const controls = []
for (const mode of ['none', 'same-row']) {
  const before = probeRow(await load(`baseline-ctrl2/${mode}-1.json`, 'probe'))
  const after = probeRow(await load(`final-ctrl2/${mode}-1.json`, 'probe'))
  controls.push({
    mode,
    fixture: 'Deterministic injected message timestamp: 2026-11-04T00:00:00.000Z; separate from original wall-clock fixture.',
    ...compare(before.map(probeMetrics), after.map(probeMetrics)),
  })
}
const probeInputs = inputs.filter((input) => 'measurement' in input.data)
for (const input of probeInputs) {
  if (!input.path.startsWith('baseline-') || !('measurement' in input.data)) continue
  const after = probeInputs.find((candidate) => candidate.path === input.path.replace('baseline-', 'final-'))
  if (!after || !('measurement' in after.data)) continue
  const mismatches = probeDifferences(input.data, after.data)
  if (mismatches.length && !input.path.startsWith('baseline-controls/')) throw new Error(`Pointer workload/window/retention/path mismatch: ${input.path}: ${JSON.stringify(mismatches)}`)
}
const driverHashes = [...new Set(probeInputs.flatMap((input) => 'measurement' in input.data ? [input.data.scriptSha256] : []))]
for (const input of probeInputs) {
  if (!('measurement' in input.data)) continue
  const expected = input.path.includes('-ctrl2/')
    ? '07b278ccf059e1786536dc07d3c97240bcd78b1d0604a69fcf33793e5377539a'
    : '2b85dfd55ba727ad9089b42eafaab7b4c35e09b86e62569ac162ae4318e4e5fa'
  if (input.data.scriptSha256 !== expected) throw new Error(`Pointer resource driver differs from its frozen fixture: ${input.path}`)
}
const result = {
  generatedAt: new Date().toISOString(),
  status: missing.length ? 'pending' : 'complete',
  units: { cpuPercent: 'percent of one logical core', memory: 'bytes', eventLoopLag: 'milliseconds', rate: 'processed messages/second' },
  limitations: [
    'A single default matrix sample flags changes for investigation; it does not establish a repeated regression.',
    'Production target baseline varies with shared host load; repeat a baseline if comparisons exceed 5% or remain inconclusive.',
    'The coupled generator demonstrates delivered throughput, not maximum sustainable external throughput.',
  ],
  inputFiles: inputs.map(({ path, sha256, bytes, data }) => ({ path, sha256, bytes, provenance: data.provenance, ...('measurement' in data ? { nativeManifest: data.nativeManifest, scriptSha256: data.scriptSha256, configSha256: data.configSha256 } : { environment: data.environment }) })),
  resourceDriverHashes: driverHashes,
  matrix,
  target: compare(targetBefore, targetAfter),
  fastPointer: compare(fastBefore, fastAfter),
  originalControls,
  controls,
  missing,
}
await Bun.write(destination, JSON.stringify(result, null, 2))
console.log(JSON.stringify({ destination, status: result.status, inputs: inputs.length, missing, target: result.target, fastPointer: result.fastPointer, matrixInvestigations: matrix.filter((row) => row.investigations.length).map(({ scenario, investigations }) => ({ scenario, investigations })) }, null, 2))
if (requireFinal && missing.length) process.exitCode = 1
