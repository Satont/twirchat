const root = '/home/satont/.codex/worktrees/performance-next/chat'
const label = process.argv[2] ?? 'baseline'
for (let repetition = 1; repetition <= 3; repetition++) {
  const output = `/home/satont/.cache/th/${label}-target-${repetition}`
  const child = Bun.spawn([process.execPath, 'run', '--cwd', 'packages/desktop', 'bench:chat', '--scenario', 'c50-r5000-p4', '--mode', 'production', '--duration', '30', '--output', output], {cwd: root, stdout:'inherit', stderr:'inherit'})
  if (await child.exited !== 0) throw new Error(`Failed ${output}`)
}
