import { createHash } from 'node:crypto'
import { existsSync } from 'node:fs'
import { copyFile, mkdir, symlink, unlink } from 'node:fs/promises'
import { join } from 'node:path'

import { z } from '/home/satont/.codex/worktrees/performance-next/chat/packages/desktop/node_modules/zod'
import { readBenchmarkProvenance } from '/home/satont/.codex/worktrees/performance-next/chat/packages/desktop/scripts/bench-metrics'

const repo = '/home/satont/.codex/worktrees/performance-next/chat'
const qa = '/home/satont/.cache/twirchat/focus-qa'
const outputRoot = '/home/satont/.cache/th'
const nativeRoot = join(repo, 'packages/desktop/native/gpuix')
const artifactRoot = join(repo, 'packages/desktop/dist/native')
const artifactName = 'gpuix.linux-x64.node'
const patchName = 'gpuix-focus-sync.patch'
const gitHead = '8a9665e04f8964a5dc3f46e65b1578233a8eb265'
const identities = {
  baseline: { sourceHash: 'd8ad6b1a4dfc4f6aa8ff869b2cf9ed9715a896a822bff03c54daad4776630dd2', sha256: 'e12a5a588389b87d6e7849699c2cf260590379593436db2c34fe3c1d3b308914' },
  final: { sourceHash: '7726a43b8af0351d1025e8b283f923a3250731e90ee8b8ae0e86f5c4c5fab7f5', sha256: '9167fe97d8be98517296d008f9c5bbaeb3f056e5e26159523db3e6147d47682f' },
}
const manifestSchema = z.object({ sha256: z.string(), version: z.string(), patchDigest: z.string() }).passthrough()
const allowed = new Set([
  ...[1, 10, 50].flatMap((channels) => [0, 100, 1000, 5000].map((rate) => `c${channels}-r${rate}-p1`)),
  'c50-r1000-p4', 'c50-r5000-p4', 'c100-r5000-p4',
])
const scenarioSchema = z.string().refine((value) => allowed.has(value), 'Unknown default benchmark scenario')
const scenarios = [...new Set(z.array(scenarioSchema).parse(process.argv.length > 2 ? process.argv.slice(2) : ['c1-r1000-p1']))]
if (process.env.TWIRCHAT_FOCUS_BALANCED_LOCKED !== '1') {
  const locked = Bun.spawn(['flock', '-n', join(qa, 'measurement.lock'), 'flock', '-n', '/home/satont/.cache/twirchat/hover-qa/measurement.lock', process.execPath, import.meta.path, ...scenarios], { cwd: repo, env: { ...process.env, TWIRCHAT_FOCUS_BALANCED_LOCKED: '1' }, stdout: 'inherit', stderr: 'inherit' })
  process.exit(await locked.exited)
}
async function sha(path: string) {
  return createHash('sha256').update(new Uint8Array(await Bun.file(path).arrayBuffer())).digest('hex')
}
async function assertStage(version: keyof typeof identities) {
  const provenance = await readBenchmarkProvenance(repo)
  if (provenance.gitHead !== gitHead || provenance.sourceHash !== identities[version].sourceHash) throw new Error(`Unexpected ${version} runtime sources: ${JSON.stringify(provenance)}`)
  const value: unknown = await Bun.file(join(artifactRoot, `${artifactName}.json`)).json()
  const native = manifestSchema.parse(value)
  if (native.sha256 !== identities[version].sha256 || await sha(join(artifactRoot, artifactName)) !== native.sha256) throw new Error(`Unexpected ${version} native artifact`)
  return { version, provenance, native }
}
await assertStage('final')
if (await sha(join(nativeRoot, 'patches', patchName)) !== '7b35451e2389dfffcdd999972cf984838f2b6a427d2c476e86bf5ef90a481a72') throw new Error('Final focus patch changed')
if (await sha(join(qa, 'artifacts', artifactName)) !== identities.baseline.sha256) throw new Error('Baseline backup bytes changed')
const jobs = scenarios.flatMap((scenario) => ['baseline', 'final'].flatMap((version) => [1, 2, 3].map((repetition) => ({
  scenario, version, repetition,
  alias: join(outputRoot, `focus-balanced-${version}-${scenario}-${repetition}`),
  physical: join(outputRoot, `fb${version === 'baseline' ? 'b' : 'f'}-${scenario.replaceAll('-', '')}-${repetition}`),
}))))
for (const job of jobs) {
  if (existsSync(job.alias) || existsSync(job.physical)) throw new Error(`Fresh output required: ${job.alias} / ${job.physical}`)
  if (join(job.physical, job.scenario, 'twirchat-gui-qa-XXXXXX/runtime/twirchat-qa').length >= 108) throw new Error('Private Wayland socket path exceeds limit')
}
// Snapshots and all repository mutations occur only after the explicit future invocation reaches here.
const saved = join(qa, 'artifacts-final')
await mkdir(saved, { recursive: true })
for (const [source, name] of [[join(nativeRoot, 'source.json'), 'source.json'], [join(nativeRoot, 'patches', patchName), patchName], [join(artifactRoot, artifactName), artifactName], [join(artifactRoot, `${artifactName}.json`), `${artifactName}.json`]]) {
  const destination = join(saved, name)
  if (existsSync(destination) && await sha(destination) !== await sha(source)) throw new Error(`Refusing to replace a different final snapshot: ${destination}`)
  await copyFile(source, destination)
}
async function restoreFinal() {
  await copyFile(join(saved, patchName), join(nativeRoot, 'patches', patchName))
  await copyFile(join(saved, 'source.json'), join(nativeRoot, 'source.json'))
  await copyFile(join(saved, artifactName), join(artifactRoot, artifactName))
  await copyFile(join(saved, `${artifactName}.json`), join(artifactRoot, `${artifactName}.json`))
  return assertStage('final')
}
const stageProofs: Awaited<ReturnType<typeof assertStage>>[] = []
async function installStage(version: keyof typeof identities) {
  if (version === 'final') return restoreFinal()
  if (existsSync(join(nativeRoot, 'patches', patchName))) await unlink(join(nativeRoot, 'patches', patchName))
  await copyFile(join(qa, 'baseline-source.json'), join(nativeRoot, 'source.json'))
  await copyFile(join(qa, 'artifacts', artifactName), join(artifactRoot, artifactName))
  await copyFile(join(qa, 'artifacts', `${artifactName}.json`), join(artifactRoot, `${artifactName}.json`))
  return assertStage('baseline')
}
const order: [keyof typeof identities, number][] = [['final', 1], ['baseline', 1], ['baseline', 2], ['final', 2], ['final', 3], ['baseline', 3]]
if (scenarios.length !== 1 || scenarios[0] !== 'c1-r1000-p1') throw new Error('Balanced diagnostic is scoped to c1-r1000-p1')
try {
  for (const [version, repetition] of order) {
    stageProofs.push(await installStage(version))
    await Bun.write(join(qa, 'balanced-version-provenance.json'), JSON.stringify(stageProofs, null, 2))
    for (const job of jobs.filter((job) => job.version === version && job.repetition === repetition)) {
      await assertStage(version)
      const command = [process.execPath, 'run', '--cwd', 'packages/desktop', 'bench:chat', '--scenario', job.scenario, '--mode', 'development', '--duration', '12', '--warmup', '3', '--output', job.physical]
      console.log(JSON.stringify({ version, scenario: job.scenario, repetition, alias: job.alias, physical: job.physical, command }))
      const child = Bun.spawn(command, { cwd: repo, stdout: 'inherit', stderr: 'inherit' })
      if (await child.exited !== 0) throw new Error(`Benchmark failed: ${job.physical}`)
      await assertStage(version)
      await symlink(job.physical, job.alias, 'dir')
    }
  }
} finally {
  const restored = await restoreFinal()
  await Bun.write(join(qa, 'balanced-final-restored.json'), JSON.stringify(restored, null, 2))
  console.log('Restored and verified original .10 source, patch and native artifact.')
}
