import { createHash } from 'node:crypto'
import { join } from 'node:path'

import { z } from '/home/satont/.codex/worktrees/performance-next/chat/packages/desktop/node_modules/zod'
import { benchmarkProvenanceSchema } from '/home/satont/.codex/worktrees/performance-next/chat/packages/desktop/scripts/bench-metrics'

const root = '/home/satont/.cache/th'
const qa = '/home/satont/.cache/twirchat/focus-qa'
const expected = {
  baseline: 'd8ad6b1a4dfc4f6aa8ff869b2cf9ed9715a896a822bff03c54daad4776630dd2',
  final: '7726a43b8af0351d1025e8b283f923a3250731e90ee8b8ae0e86f5c4c5fab7f5',
}
const schema = z.object({
  config: z.object({ channels: z.number(), rate: z.number(), panes: z.number(), durationSeconds: z.literal(12), warmupSeconds: z.literal(3) }),
  reactMode: z.literal('development'), nativeWindow: z.object({ width: z.literal(1200), height: z.literal(800) }),
  retainedMessages: z.number(), provenance: benchmarkProvenanceSchema,
  cpuPercent: z.number(), rssMedianBytes: z.number(), rssPeakBytes: z.number(), heapPeakBytes: z.number(),
  achievedRate: z.number(), eventLoopLagP50Ms: z.number(), eventLoopLagP95Ms: z.number(), eventLoopLagMaxMs: z.number(),
  userTimingMeasureCount: z.number(), requestedMessages: z.number(), generatedMessages: z.number(), processedMessages: z.number(), processedAfterDrain: z.number(),
})
const fileSchema = z.object({ provenance: benchmarkProvenanceSchema, results: z.array(schema) })
type Row = z.infer<typeof schema>
const fields: (keyof Pick<Row, 'cpuPercent' | 'rssMedianBytes' | 'rssPeakBytes' | 'heapPeakBytes' | 'achievedRate' | 'eventLoopLagP50Ms' | 'eventLoopLagP95Ms' | 'eventLoopLagMaxMs' | 'userTimingMeasureCount'>)[] = ['cpuPercent', 'rssMedianBytes', 'rssPeakBytes', 'heapPeakBytes', 'achievedRate', 'eventLoopLagP50Ms', 'eventLoopLagP95Ms', 'eventLoopLagMaxMs', 'userTimingMeasureCount']
const scenarioSchema = z.string().regex(/^c\d+-r\d+-p\d+$/u)
const scenarios = [...new Set(z.array(scenarioSchema).parse(process.argv.length > 2 ? process.argv.slice(2) : ['c1-r1000-p1', 'c50-r1000-p1']))]
const missing: string[] = []
const evidence: { path: string; sha256: string; bytes: number; provenance: z.infer<typeof benchmarkProvenanceSchema> }[] = []
async function read(path: string, version: keyof typeof expected) {
  const file = Bun.file(join(root, path))
  if (!(await file.exists())) { missing.push(path); return null }
  const bytes = new Uint8Array(await file.arrayBuffer())
  const value: unknown = JSON.parse(new TextDecoder().decode(bytes))
  const data = fileSchema.parse(value)
  if (data.provenance.gitHead !== '8a9665e04f8964a5dc3f46e65b1578233a8eb265' || data.provenance.sourceHash !== expected[version]) throw new Error(`Unexpected source identity: ${path}`)
  for (const row of data.results) if (JSON.stringify(row.provenance) !== JSON.stringify(data.provenance)) throw new Error(`Row/source mismatch: ${path}`)
  evidence.push({ path, sha256: createHash('sha256').update(bytes).digest('hex'), bytes: bytes.length, provenance: data.provenance })
  return data.results
}
function name(row: Row) { return `c${row.config.channels}-r${row.config.rate}-p${row.config.panes}` }
function statistics(rows: Row[]) {
  const metrics: Record<string, { median: number; min: number; max: number }> = {}
  for (const field of [...fields, 'processedFraction']) {
    const values = rows.map((row) => field === 'processedFraction' ? row.requestedMessages > 0 ? row.processedMessages / row.requestedMessages : 1 : Reflect.get(row, field)).filter((value: unknown): value is number => typeof value === 'number').toSorted((a, b) => a - b)
    const min = values[0], max = values.at(-1), middle = values[Math.floor(values.length / 2)], previous = values[Math.floor(values.length / 2) - 1]
    if (min !== undefined && max !== undefined && middle !== undefined) metrics[field] = { min, max, median: values.length % 2 === 0 && previous !== undefined ? (middle + previous) / 2 : middle }
  }
  return metrics
}
const beforeMatrix = await read('focus-baseline-matrix/results.json', 'baseline')
const afterMatrix = await read('focus-final-matrix/results.json', 'final')
const comparisons = []
for (const scenario of scenarios) {
  const baseline: Row[] = [], final: Row[] = []
  for (const version of ['baseline', 'final'] satisfies (keyof typeof expected)[]) for (let i = 1; i <= 3; i++) {
    const rows = await read(`focus-repeat-${version}-${scenario}-${i}/results.json`, version)
    if (!rows) continue
    if (rows.length !== 1) throw new Error('Expected one focused repeat per file')
    for (const row of rows) {
      if (name(row) !== scenario || row.retainedMessages !== row.config.channels * 200) throw new Error('Repeated workload/retention mismatch')
      const reference = beforeMatrix?.find((candidate) => name(candidate) === scenario)
      if (!reference || JSON.stringify(reference.config) !== JSON.stringify(row.config)) throw new Error('Repeated scenario differs from initial matrix')
      ;(version === 'baseline' ? baseline : final).push(row)
    }
  }
  const first = statistics(baseline), last = statistics(final), changePercent: Record<string, number | null> = {}, investigations: string[] = []
  if (baseline.length === 3 && final.length === 3) for (const [field, a] of Object.entries(first)) {
    const b = last[field]
    if (!b) continue
    const delta = a.median === 0 ? null : (b.median / a.median - 1) * 100
    changePercent[field] = delta
    if (['cpuPercent', 'rssMedianBytes', 'rssPeakBytes'].includes(field) && delta !== null && delta > 5) investigations.push(`Repeated ${field} median increased ${delta.toFixed(2)}%`)
  }
  comparisons.push({ scenario, initialMatrix: { baseline: beforeMatrix?.find((row) => name(row) === scenario), final: afterMatrix?.find((row) => name(row) === scenario) }, baseline: { count: baseline.length, metrics: first, rows: baseline }, final: { count: final.length, metrics: last, rows: final }, changePercent, investigations })
}
const proof: unknown = await Bun.file(join(qa, 'repeat-version-provenance.json')).exists() ? await Bun.file(join(qa, 'repeat-version-provenance.json')).json() : null
const unresolved = comparisons.flatMap((row) => row.investigations.map((message) => ({ scenario: row.scenario, message })))
const result = { schema: 1, status: missing.length ? 'pending' : 'complete', gateStatus: missing.length ? 'pending' : unresolved.length ? 'blocked-repeated-regression' : 'no-repeated-cpu-rss-flag', unresolved, generatedAt: new Date().toISOString(), method: 'Three fresh development12s/3swarmup runs per version/scenario; initial single matrix spikes retained separately, never pooled into repeated medians.', units: { cpuPercent: 'percent of one logical core', memory: 'bytes', lag: 'milliseconds' }, evidence, versionProof: proof, comparisons, missing }
await Bun.write(join(qa, 'repeat-analysis.json'), JSON.stringify(result, null, 2))
console.log(JSON.stringify({ status: result.status, missing, comparisons: comparisons.map(({ scenario, baseline, final, changePercent, investigations }) => ({ scenario, baseline: { count: baseline.count, metrics: baseline.metrics }, final: { count: final.count, metrics: final.metrics }, changePercent, investigations })) }, null, 2))
if (process.env.TWIRCHAT_REQUIRE_COMPLETE === '1' && result.status !== 'complete') process.exitCode = 1
