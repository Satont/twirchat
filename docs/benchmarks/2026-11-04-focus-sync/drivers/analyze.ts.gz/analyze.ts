import { createHash } from 'node:crypto'
import { join } from 'node:path'

import { z } from '/home/satont/.codex/worktrees/performance-next/chat/packages/desktop/node_modules/zod'
import { benchmarkProvenanceSchema } from '/home/satont/.codex/worktrees/performance-next/chat/packages/desktop/scripts/bench-metrics'

const root = process.env.TWIRCHAT_FOCUS_RESULTS ?? '/home/satont/.cache/th'
const labelSchema = z.string().regex(/^[a-z0-9-]+$/u)
const beforeLabel = labelSchema.parse(process.argv[2] ?? 'focus-baseline')
const afterLabel = labelSchema.parse(process.argv[3] ?? 'focus-final')
const output = process.argv[4] ?? '/home/satont/.cache/twirchat/focus-qa/analysis.json'
const resources = z.object({
  wallMs: z.number().positive(), cpuPercent: z.number().nonnegative(),
  rssMedianBytes: z.number(), rssPeakBytes: z.number(), heapPeakBytes: z.number(),
  eventLoopLagP50Ms: z.number(), eventLoopLagP95Ms: z.number(), eventLoopLagMaxMs: z.number(),
})
const box = z.object({ width: z.number(), height: z.number() }).passthrough()
const pointerSchema = z.object({ kind: z.string(), sweepSeconds: z.number(), path: z.unknown(), offeredCalls: z.number(), dispatchedNativeCalls: z.number(), actualCallsPerSecond: z.number() })
const probeSchema = z.object({
  ok: z.literal(true), config: z.object({ durationSeconds: z.number(), warmupSeconds: z.number() }).passthrough(),
  configSha256: z.string(), reactMode: z.string(), bunVersion: z.string(), compositor: z.string(),
  scriptSha256: z.string(), provenance: benchmarkProvenanceSchema,
  nativeManifest: z.object({ sha256: z.string(), patchDigest: z.string() }).passthrough(),
  nativeWindow: box, initialRetainedMessages: z.number(),
  measurement: resources.extend({ actualRate: z.number(), retainedMessages: z.number(), pointer: pointerSchema.nullable(), nativeFrames: z.number(), nativeFramesPerSecond: z.number(), totalPresents: z.number(), totalPresentsPerSecond: z.number(), nativeMutationBatches: z.number(), nativeMutationOperations: z.number() }),
})
const benchRow = resources.extend({
  config: z.object({ channels: z.number(), rate: z.number(), panes: z.number(), durationSeconds: z.number(), warmupSeconds: z.number() }),
  reactMode: z.string(), bunVersion: z.string(), compositor: z.string(), nativeWindow: box,
  retainedMessages: z.number(), requestedMessages: z.number(), generatedMessages: z.number(), processedMessages: z.number(), processedAfterDrain: z.number(), achievedRate: z.number(), userTimingMeasureCount: z.number(), provenance: benchmarkProvenanceSchema,
})
const benchSchema = z.object({ environment: z.object({}).passthrough(), provenance: benchmarkProvenanceSchema, results: z.array(benchRow) })
type Probe = z.infer<typeof probeSchema>
type BenchRow = z.infer<typeof benchRow>
type Input = Probe | z.infer<typeof benchSchema>
interface Evidence { path: string; sha256: string; bytes: number; data: Input }
interface Row { metrics: Record<string, number>; contract: object }
const files: Evidence[] = []
const missing: string[] = []
async function read(path: string, kind: 'probe' | 'bench') {
  const file = Bun.file(join(root, path))
  if (!(await file.exists())) { missing.push(path); return null }
  const bytes = new Uint8Array(await file.arrayBuffer())
  const value: unknown = JSON.parse(new TextDecoder().decode(bytes))
  const data = kind === 'probe' ? probeSchema.parse(value) : benchSchema.parse(value)
  files.push({ path, sha256: createHash('sha256').update(bytes).digest('hex'), bytes: bytes.length, data })
  return data
}
function resourceMetrics(value: z.infer<typeof resources>) {
  return { cpuPercent: value.cpuPercent, rssMedianBytes: value.rssMedianBytes, rssPeakBytes: value.rssPeakBytes, heapPeakBytes: value.heapPeakBytes, eventLoopLagP50Ms: value.eventLoopLagP50Ms, eventLoopLagP95Ms: value.eventLoopLagP95Ms, eventLoopLagMaxMs: value.eventLoopLagMaxMs, wallMs: value.wallMs }
}
function probeRow(value: Probe): Row {
  const p = value.measurement.pointer
  return {
    metrics: { ...resourceMetrics(value.measurement), actualRate: value.measurement.actualRate, nativeFrames: value.measurement.nativeFrames, nativeFramesPerSecond: value.measurement.nativeFramesPerSecond, totalPresents: value.measurement.totalPresents, totalPresentsPerSecond: value.measurement.totalPresentsPerSecond, nativeMutationBatches: value.measurement.nativeMutationBatches, nativeMutationOperations: value.measurement.nativeMutationOperations, pointerCallsPerSecond: p?.actualCallsPerSecond ?? 0, pointerCompletedFraction: p && p.offeredCalls > 0 ? p.dispatchedNativeCalls / p.offeredCalls : 1 },
    contract: { config: value.config, configSha256: value.configSha256, mode: value.reactMode, bun: value.bunVersion, compositor: value.compositor, window: value.nativeWindow, initialRetained: value.initialRetainedMessages, retained: value.measurement.retainedMessages, driver: value.scriptSha256, pointerPath: p?.path, pointerKind: p?.kind, pointerSweepSeconds: p?.sweepSeconds, offeredCalls: p?.offeredCalls },
  }
}
function loadRow(value: BenchRow): Row {
  return { metrics: { ...resourceMetrics(value), actualRate: value.achievedRate, processedFraction: value.requestedMessages > 0 ? value.processedMessages / value.requestedMessages : 1, offeredMessages: value.requestedMessages, generatedMessages: value.generatedMessages, processedMessages: value.processedMessages, processedAfterDrain: value.processedAfterDrain, userTimingMeasureCount: value.userTimingMeasureCount }, contract: { config: value.config, mode: value.reactMode, bun: value.bunVersion, compositor: value.compositor, window: value.nativeWindow, retained: value.retainedMessages } }
}
function stats(rows: Row[]) {
  const result: Record<string, { median: number; min: number; max: number }> = {}
  for (const key of new Set(rows.flatMap((row) => Object.keys(row.metrics)))) {
    const values = rows.map((row) => row.metrics[key]).filter((value) => value !== undefined).toSorted((a, b) => a - b)
    const middle = Math.floor(values.length / 2), center = values[middle], previous = values[middle - 1], min = values[0], max = values.at(-1)
    if (center !== undefined && min !== undefined && max !== undefined) result[key] = { median: values.length % 2 === 0 && previous !== undefined ? (center + previous) / 2 : center, min, max }
  }
  return result
}
function compare(before: Row[], after: Row[], expected: number, productionTarget = false) {
  const baseline = { count: before.length, metrics: stats(before), contracts: before.map((row) => row.contract) }
  const final = { count: after.length, metrics: stats(after), contracts: after.map((row) => row.contract) }
  const mismatches = []
  const reference = before[0]?.contract
  for (const [side, rows] of [['baseline', before], ['final', after]] satisfies [string, Row[]][]) for (const [index, row] of rows.entries()) if (reference && JSON.stringify(row.contract) !== JSON.stringify(reference)) mismatches.push({ side, repetition: index + 1, expected: reference, actual: row.contract })
  const complete = before.length === expected && after.length === expected
  const changePercent: Record<string, number | null> = {}
  const investigations: string[] = []
  if (complete && !mismatches.length) for (const [key, left] of Object.entries(baseline.metrics)) {
    const right = final.metrics[key]
    if (!right) continue
    const delta = left.median === 0 ? null : (right.median / left.median - 1) * 100
    changePercent[key] = delta
    if (['cpuPercent', 'rssMedianBytes', 'rssPeakBytes'].includes(key) && delta !== null && delta > 5) investigations.push(`${expected > 1 ? 'Repeated' : 'Single-sample; repeat required'} ${key} median increased ${delta.toFixed(2)}%`)
  }
  for (const [side, summary] of [['baseline', baseline], ['final', final]] satisfies [string, typeof baseline][]) {
    if (productionTarget && summary.metrics.processedFraction && summary.metrics.processedFraction.min < 0.99) investigations.push(`${side} production target processed below99%of offered messages`)
    if (summary.metrics.pointerCompletedFraction && summary.metrics.pointerCompletedFraction.min < 0.99) investigations.push(`${side} dispatched below99%of offered pointer calls`)
  }
  return { status: mismatches.length ? 'not-comparable' : complete ? 'complete' : 'pending', baseline, final, changePercent, mismatches, investigations }
}
async function probes(label: string, suffix: string, count: number) {
  const rows = []
  for (let i = 1; i <= count; i++) { const value = await read(`${label}/${suffix}-${i}.json`, 'probe'); if (value && 'measurement' in value) rows.push(probeRow(value)) }
  return rows
}
const motion = compare(await probes(beforeLabel, 'cross-rows', 3), await probes(afterLabel, 'cross-rows', 3), 3)
const targets: Row[][] = [[], []]
for (const [index, label] of [beforeLabel, afterLabel].entries()) for (let i = 1; i <= 3; i++) {
  const input = await read(`${label}-target-${i}/results.json`, 'bench')
  if (!input || !('results' in input)) continue
  if (input.results.length !== 1) throw new Error('Expected one production target per file')
  for (const row of input.results) {
    if (row.reactMode !== 'production' || row.config.channels !== 50 || row.config.rate !== 5000 || row.config.panes !== 4 || row.config.durationSeconds !== 30) throw new Error('Unexpected production target workload')
    targets[index]?.push(loadRow(row))
  }
}
const production = compare(targets[0] ?? [], targets[1] ?? [], 3, true)
const controls = []
for (const mode of ['none', 'same-row']) controls.push({ mode, ...compare(await probes(`${beforeLabel}-controls`, mode, 1), await probes(`${afterLabel}-controls`, mode, 1), 1) })
const bm = await read(`${beforeLabel}-matrix/results.json`, 'bench'), fm = await read(`${afterLabel}-matrix/results.json`, 'bench')
const baselineRows = bm && 'results' in bm ? bm.results : [], finalRows = fm && 'results' in fm ? fm.results : []
const expectedCases = [...[1, 10, 50].flatMap((channels) => [0, 100, 1000, 5000].map((rate) => ({ channels, rate, panes: 1 }))), { channels: 50, rate: 1000, panes: 4 }, { channels: 50, rate: 5000, panes: 4 }, { channels: 100, rate: 5000, panes: 4 }]
const matrix = expectedCases.map((spec) => {
  const match = (row: BenchRow) => row.config.channels === spec.channels && row.config.rate === spec.rate && row.config.panes === spec.panes
  const before = baselineRows.find(match), after = finalRows.find(match)
  return { scenario: `c${spec.channels}-r${spec.rate}-p${spec.panes}`, ...compare(before ? [loadRow(before)] : [], after ? [loadRow(after)] : [], 1) }
})
const provenanceWarnings = []
for (const label of [beforeLabel, afterLabel]) {
  const stage = files.filter((file) => file.path.startsWith(`${label}/`) || file.path.startsWith(`${label}-`))
  if (new Set(stage.map((file) => file.data.provenance.sourceHash)).size > 1) provenanceWarnings.push(`${label}: multiple runtime source hashes in stage`)
  if (new Set(stage.flatMap((file) => 'measurement' in file.data ? [file.data.nativeManifest.sha256] : [])).size > 1) provenanceWarnings.push(`${label}: multiple native artifact hashes in stage`)
  for (const file of stage) if ('results' in file.data) for (const row of file.data.results) if (JSON.stringify(row.provenance) !== JSON.stringify(file.data.provenance)) provenanceWarnings.push(`${file.path}: row/root provenance mismatch`)
}
const groups = [motion, production, ...controls, ...matrix]
const summary = { schema: 1, generatedAt: new Date().toISOString(), labels: { baseline: beforeLabel, final: afterLabel }, status: groups.some((group) => group.status === 'not-comparable') || provenanceWarnings.length ? 'not-comparable' : missing.length || groups.some((group) => group.status !== 'complete') ? 'pending' : 'complete', units: { cpuPercent: 'percentofonecore', memory: 'bytes', lag: 'milliseconds' }, limitations: ['Fresh focus stage only; no previous .7→.9 percentages reused.', 'Single matrix/control samples require repeats before declaring a repeated regression.', 'Shared host; coupled generator does not prove maximum sustainable external throughput.', 'No fresh profile; previous-stage perf is diagnostic context only.'], inputFiles: files.map(({ path, sha256, bytes, data }) => ({ path, sha256, bytes, provenance: data.provenance, ...('measurement' in data ? { nativeManifest: data.nativeManifest, scriptSha256: data.scriptSha256, config: data.config, mode: data.reactMode, window: data.nativeWindow, pointer: data.measurement.pointer } : { environment: data.environment }) })), motion, production, controls, matrix, provenanceWarnings, missing }
await Bun.write(output, JSON.stringify(summary, null, 2))
console.log(JSON.stringify({ output, status: summary.status, inputCount: files.length, missing, provenanceWarnings, motion, production, flags: groups.flatMap((group) => group.investigations) }, null, 2))
if (process.argv.includes('--require-final') && summary.status !== 'complete') process.exitCode = 1
